var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/elkjs/lib/elk-api.js
var require_elk_api = __commonJS({
  "node_modules/elkjs/lib/elk-api.js"(exports, module) {
    (function(f) {
      if (typeof exports === "object" && typeof module !== "undefined") {
        module.exports = f();
      } else if (typeof define === "function" && define.amd) {
        define([], f);
      } else {
        var g;
        if (typeof window !== "undefined") {
          g = window;
        } else if (typeof global !== "undefined") {
          g = global;
        } else if (typeof self !== "undefined") {
          g = self;
        } else {
          g = this;
        }
        g.ELK = f();
      }
    })(function() {
      var define2, module2, exports2;
      return (/* @__PURE__ */ function() {
        function r(e, n, t) {
          function o(i2, f) {
            if (!n[i2]) {
              if (!e[i2]) {
                var c = "function" == typeof __require && __require;
                if (!f && c) return c(i2, true);
                if (u) return u(i2, true);
                var a = new Error("Cannot find module '" + i2 + "'");
                throw a.code = "MODULE_NOT_FOUND", a;
              }
              var p = n[i2] = { exports: {} };
              e[i2][0].call(p.exports, function(r2) {
                var n2 = e[i2][1][r2];
                return o(n2 || r2);
              }, p, p.exports, r, e, n, t);
            }
            return n[i2].exports;
          }
          for (var u = "function" == typeof __require && __require, i = 0; i < t.length; i++) o(t[i]);
          return o;
        }
        return r;
      }())({ 1: [function(require2, module3, exports3) {
        "use strict";
        Object.defineProperty(exports3, "__esModule", {
          value: true
        });
        exports3["default"] = void 0;
        function _typeof(o) {
          "@babel/helpers - typeof";
          return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
            return typeof o2;
          } : function(o2) {
            return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
          }, _typeof(o);
        }
        function _classCallCheck(a, n) {
          if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
        }
        function _defineProperties(e, r) {
          for (var t = 0; t < r.length; t++) {
            var o = r[t];
            o.enumerable = o.enumerable || false, o.configurable = true, "value" in o && (o.writable = true), Object.defineProperty(e, _toPropertyKey(o.key), o);
          }
        }
        function _createClass(e, r, t) {
          return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: false }), e;
        }
        function _toPropertyKey(t) {
          var i = _toPrimitive(t, "string");
          return "symbol" == _typeof(i) ? i : i + "";
        }
        function _toPrimitive(t, r) {
          if ("object" != _typeof(t) || !t) return t;
          var e = t[Symbol.toPrimitive];
          if (void 0 !== e) {
            var i = e.call(t, r || "default");
            if ("object" != _typeof(i)) return i;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return ("string" === r ? String : Number)(t);
        }
        var ELK2 = exports3["default"] = /* @__PURE__ */ function() {
          function ELK3() {
            var _this = this;
            var _ref = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, _ref$defaultLayoutOpt = _ref.defaultLayoutOptions, defaultLayoutOptions = _ref$defaultLayoutOpt === void 0 ? {} : _ref$defaultLayoutOpt, _ref$algorithms = _ref.algorithms, algorithms = _ref$algorithms === void 0 ? ["layered", "stress", "mrtree", "radial", "force", "disco", "sporeOverlap", "sporeCompaction", "rectpacking"] : _ref$algorithms, workerFactory = _ref.workerFactory, workerUrl = _ref.workerUrl;
            _classCallCheck(this, ELK3);
            this.defaultLayoutOptions = defaultLayoutOptions;
            this.initialized = false;
            if (typeof workerUrl === "undefined" && typeof workerFactory === "undefined") {
              throw new Error("Cannot construct an ELK without both 'workerUrl' and 'workerFactory'.");
            }
            var factory = workerFactory;
            if (typeof workerUrl !== "undefined" && typeof workerFactory === "undefined") {
              factory = function factory2(url) {
                return new Worker(url);
              };
            }
            var worker = factory(workerUrl);
            if (typeof worker.postMessage !== "function") {
              throw new TypeError("Created worker does not provide the required 'postMessage' function.");
            }
            this.worker = new PromisedWorker(worker);
            this.worker.postMessage({
              cmd: "register",
              algorithms
            }).then(function(r) {
              return _this.initialized = true;
            })["catch"](console.err);
          }
          return _createClass(ELK3, [{
            key: "layout",
            value: function layout(graph) {
              var _ref2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref2$layoutOptions = _ref2.layoutOptions, layoutOptions = _ref2$layoutOptions === void 0 ? this.defaultLayoutOptions : _ref2$layoutOptions, _ref2$logging = _ref2.logging, logging = _ref2$logging === void 0 ? false : _ref2$logging, _ref2$measureExecutio = _ref2.measureExecutionTime, measureExecutionTime = _ref2$measureExecutio === void 0 ? false : _ref2$measureExecutio;
              if (!graph) {
                return Promise.reject(new Error("Missing mandatory parameter 'graph'."));
              }
              return this.worker.postMessage({
                cmd: "layout",
                graph,
                layoutOptions,
                options: {
                  logging,
                  measureExecutionTime
                }
              });
            }
          }, {
            key: "knownLayoutAlgorithms",
            value: function knownLayoutAlgorithms() {
              return this.worker.postMessage({
                cmd: "algorithms"
              });
            }
          }, {
            key: "knownLayoutOptions",
            value: function knownLayoutOptions() {
              return this.worker.postMessage({
                cmd: "options"
              });
            }
          }, {
            key: "knownLayoutCategories",
            value: function knownLayoutCategories() {
              return this.worker.postMessage({
                cmd: "categories"
              });
            }
          }, {
            key: "terminateWorker",
            value: function terminateWorker() {
              if (this.worker) this.worker.terminate();
            }
          }]);
        }();
        var PromisedWorker = /* @__PURE__ */ function() {
          function PromisedWorker2(worker) {
            var _this2 = this;
            _classCallCheck(this, PromisedWorker2);
            if (worker === void 0) {
              throw new Error("Missing mandatory parameter 'worker'.");
            }
            this.resolvers = {};
            this.worker = worker;
            this.worker.onmessage = function(answer) {
              setTimeout(function() {
                _this2.receive(_this2, answer);
              }, 0);
            };
          }
          return _createClass(PromisedWorker2, [{
            key: "postMessage",
            value: function postMessage2(msg) {
              var id = this.id || 0;
              this.id = id + 1;
              msg.id = id;
              var self2 = this;
              return new Promise(function(resolve2, reject) {
                self2.resolvers[id] = function(err2, res) {
                  if (err2) {
                    self2.convertGwtStyleError(err2);
                    reject(err2);
                  } else {
                    resolve2(res);
                  }
                };
                self2.worker.postMessage(msg);
              });
            }
          }, {
            key: "receive",
            value: function receive(self2, answer) {
              var json = answer.data;
              var resolver = self2.resolvers[json.id];
              if (resolver) {
                delete self2.resolvers[json.id];
                if (json.error) {
                  resolver(json.error);
                } else {
                  resolver(null, json.data);
                }
              }
            }
          }, {
            key: "terminate",
            value: function terminate() {
              if (this.worker) {
                this.worker.terminate();
              }
            }
          }, {
            key: "convertGwtStyleError",
            value: function convertGwtStyleError(err2) {
              if (!err2) {
                return;
              }
              var javaException = err2["__java$exception"];
              if (javaException) {
                if (javaException.cause && javaException.cause.backingJsObject) {
                  err2.cause = javaException.cause.backingJsObject;
                  this.convertGwtStyleError(err2.cause);
                }
                delete err2["__java$exception"];
              }
            }
          }]);
        }();
      }, {}], 2: [function(require2, module3, exports3) {
        "use strict";
        var ELK2 = require2("./elk-api.js")["default"];
        Object.defineProperty(module3.exports, "__esModule", {
          value: true
        });
        module3.exports = ELK2;
        ELK2["default"] = ELK2;
      }, { "./elk-api.js": 1 }] }, {}, [2])(2);
    });
  }
});

// src/canvas-prototype/core/index.mjs
var copy = (value) => structuredClone(value);
var ENGINEERING_RELATIONSHIPS = Object.freeze([
  "derive",
  "derivation",
  "refine",
  "refinement",
  "satisfy",
  "satisfaction",
  "verify",
  "verification",
  "allocate",
  "allocation",
  "dependency",
  "composition",
  "reference",
  "connection",
  "flow",
  "item-flow",
  "control-flow",
  "causation"
]);
var FORBIDDEN_SHORTCUTS = /* @__PURE__ */ new Set(["type", "typing", "specialization", "owner", "owningMembership", "ownedMembership", "documentation", "membership"]);
var endpoint = (edge, side) => side === "source" ? edge.source ?? edge.fromId ?? edge.from_id ?? edge.from : edge.target ?? edge.toId ?? edge.to_id ?? edge.to;
var nativeEdges = (graph) => (graph.relationships ?? []).map((edge) => ({ ...edge, source: endpoint(edge, "source"), target: endpoint(edge, "target") }));
var allowedKinds = (options) => new Set((options.relationshipKinds ?? ENGINEERING_RELATIONSHIPS).filter((kind) => !FORBIDDEN_SHORTCUTS.has(kind)));
function graphPolicy(graph, options) {
  const elements = new Map((graph.elements ?? []).map((element2) => [element2.id, element2]));
  const scope = options.scopeIds ? /* @__PURE__ */ new Set([...options.scopeIds, ...options.includedIds ?? []]) : null;
  const explicit = new Set(options.includedIds ?? []);
  const allowedElement = (id) => {
    const element2 = elements.get(id);
    if (!element2) return "unavailable";
    if (scope && !scope.has(id)) return "outside-scope";
    if ((element2.layer === "metamodel" || element2.metamodel === true) && !explicit.has(id)) return "metamodel-boundary";
    return null;
  };
  return { elements, edges: nativeEdges(graph), kinds: allowedKinds(options), allowedElement };
}
function engineeringContext(graph, options = {}) {
  const { focus, depth = 1, budget = 24 } = options;
  if (!Number.isInteger(depth) || depth < 0 || !Number.isInteger(budget) || budget < 1) throw new Error("Invalid context depth or budget");
  const policy = graphPolicy(graph, options), wanted = /* @__PURE__ */ new Set(), omissions = [], seenOmissions = /* @__PURE__ */ new Set();
  const omit = (edge, target, reason) => {
    const key = `${edge?.id}:${target}:${reason}`;
    if (!seenOmissions.has(key)) {
      seenOmissions.add(key);
      omissions.push({ relationshipId: edge?.id ?? null, target, reason });
    }
  };
  const rootReason = policy.allowedElement(focus);
  if (rootReason) {
    omit(null, focus, rootReason);
    return { elements: [], relationships: [], omissions };
  }
  wanted.add(focus);
  const queue = [[focus, 0]];
  while (queue.length) {
    const [id, distance] = queue.shift();
    for (const edge of policy.edges) {
      if (edge.source !== id && edge.target !== id) continue;
      const target = edge.source === id ? edge.target : edge.source;
      if (!policy.kinds.has(edge.kind)) {
        omit(edge, target, "relationship-policy");
        continue;
      }
      const reason = policy.allowedElement(target);
      if (reason) {
        omit(edge, target, reason);
        continue;
      }
      if (wanted.has(target)) continue;
      if (distance >= depth) {
        omit(edge, target, "depth");
        continue;
      }
      if (wanted.size >= budget) {
        omit(edge, target, "budget");
        continue;
      }
      wanted.add(target);
      queue.push([target, distance + 1]);
    }
  }
  return copy({ elements: [...wanted].map((id) => policy.elements.get(id)), relationships: policy.edges.filter((edge) => policy.kinds.has(edge.kind) && wanted.has(edge.source) && wanted.has(edge.target)), omissions });
}
function findEngineeringRoute(graph, options = {}) {
  const { from, to, maxHops = 12 } = options, policy = graphPolicy(graph, options), omissions = [];
  for (const id of [from, to]) {
    const reason = policy.allowedElement(id);
    if (reason) return { found: false, elements: [], relationships: [], omissions: [{ target: id, reason }] };
  }
  const visited = /* @__PURE__ */ new Set([from]), queue = [{ id: from, path: [from], edges: [] }];
  while (queue.length) {
    const current = queue.shift();
    if (current.id === to) return copy({ found: true, elements: current.path.map((id) => policy.elements.get(id)), relationships: current.edges, omissions });
    for (const edge of policy.edges) {
      if (edge.source !== current.id && edge.target !== current.id) continue;
      const target = edge.source === current.id ? edge.target : edge.source;
      const reason = !policy.kinds.has(edge.kind) ? "relationship-policy" : policy.allowedElement(target);
      if (reason) {
        omissions.push({ relationshipId: edge.id, target, reason });
        continue;
      }
      if (visited.has(target)) continue;
      if (current.edges.length >= maxHops) {
        omissions.push({ relationshipId: edge.id, target, reason: "hop-limit" });
        continue;
      }
      visited.add(target);
      queue.push({ id: target, path: [...current.path, target], edges: [...current.edges, edge] });
    }
  }
  return copy({ found: false, elements: [], relationships: [], omissions });
}
function directTypingContext(graph, id) {
  const elements = new Map((graph.elements ?? []).map((element2) => [element2.id, element2]));
  const relationships = nativeEdges(graph).filter((edge) => ["type", "typing"].includes(edge.kind) && (edge.source === id || edge.target === id));
  const ids = /* @__PURE__ */ new Set([id]);
  for (const edge of relationships) {
    ids.add(edge.source);
    ids.add(edge.target);
  }
  return copy({ elements: [...ids].filter((key) => elements.has(key)).map((key) => elements.get(key)), relationships });
}
function projectView(view) {
  const nodes = (view.nodes ?? []).map((node) => ({ ...copy(node), id: node.id, semanticId: node.semanticId ?? node.semantic_id ?? null, parentId: node.parentId ?? node.parent ?? null }));
  if (nodes.some((node) => typeof node.id !== "string")) throw new Error("Native drawing node lacks a representation ID");
  if (new Set(nodes.map((node) => node.id)).size !== nodes.length) throw new Error("Duplicate representation ID");
  const nodeIds = new Set(nodes.map((node) => node.id));
  const edges = (view.edges ?? []).map((edge, index) => ({ ...copy(edge), id: edge.id ?? `${view.id ?? "view"}:edge:${index}`, source: endpoint(edge, "source"), target: endpoint(edge, "target") }));
  if (edges.some((edge) => !nodeIds.has(edge.source) || !nodeIds.has(edge.target))) throw new Error("Native edge references an unavailable drawing node");
  return { ...copy(view), nodes, edges };
}
function semanticIds(scene2) {
  return [...new Set((scene2.nodes ?? scene2.view?.nodes ?? []).map((node) => node.semanticId).filter(Boolean))];
}
function planTransition(fromScene, toScene, options = {}) {
  const previous = fromScene.view ?? fromScene, next = toScene.view ?? toScene;
  const oldIds = semanticIds(previous), newIds = semanticIds(next), duration = options.reducedMotion ? 0 : 360;
  const correspondence = oldIds.filter((id) => newIds.includes(id)).map((semanticId) => ({ semanticId, fromRepresentationIds: previous.nodes.filter((node) => node.semanticId === semanticId).map((node) => node.id), toRepresentationIds: next.nodes.filter((node) => node.semanticId === semanticId).map((node) => node.id) }));
  if (previous.kind === next.kind) return { mode: "same-kind", correspondence, stages: [{ kind: "reflow", viewKind: next.kind, semanticIds: newIds, duration }] };
  const route2 = options.graph && fromScene.focus && toScene.focus ? findEngineeringRoute(options.graph, { ...options, from: fromScene.focus, to: toScene.focus }) : null;
  const journey = route2?.found ? route2.elements.map((element2) => element2.id) : [];
  const all = [.../* @__PURE__ */ new Set([...oldIds, ...journey, ...newIds])];
  return { mode: "cross-kind", correspondence, route: route2, stages: [
    { kind: "gv-bridge", viewKind: "gv", semanticIds: oldIds, duration },
    { kind: "gv-journey", viewKind: "gv", semanticIds: all, route: route2?.found ? route2.relationships : [], disconnected: route2?.found === false, duration },
    { kind: "gv-gather", viewKind: "gv", semanticIds: newIds, duration },
    { kind: "morph", viewKind: next.kind, semanticIds: newIds, duration }
  ] };
}

// src/canvas-prototype/graph.mjs
var refs = (value) => Array.isArray(value) ? value.flatMap(refs) : value && typeof value === "object" && typeof value["@id"] === "string" ? [value["@id"]] : [];
var camel = (value) => Array.isArray(value) ? value.map(camel) : value && typeof value === "object" ? Object.fromEntries(Object.entries(value).map(([k, v]) => [k.replace(/_([a-z])/g, (_, c) => c.toUpperCase()), camel(v)])) : value;
function adaptNativeView(raw, name) {
  const v = camel(raw);
  return { ...v, id: name, title: name, nodes: v.nodes ?? [], edges: v.edges ?? [], notices: v.notices ?? [] };
}
function modelGraph(raw, views = []) {
  const elements = raw.map((e) => ({ id: e["@id"], kind: e["@type"], name: e.declaredName || e.qualifiedName || e["@id"], qualifiedName: e.qualifiedName, description: e.body || "", native: e, layer: e["sysx:sourceLine"] ? "project" : "library" }));
  const index = new Map(elements.map((e) => [e.id, e])), relationships = [];
  const add = (source, target, kind, id, nativeRelationship) => {
    if (!source || !target) return;
    relationships.push({ id, source, target, kind, label: kind, authority: "native-api", nativeRelationship });
  };
  for (const item of raw) {
    const id = item["@id"];
    if (item["@type"] === "Dependency") for (const client of refs(item.client)) for (const supplier of refs(item.supplier)) add(client, supplier, "dependency", "api:" + id + ":" + client + ":" + supplier, id);
    if (["PartUsage", "PartDefinition"].includes(item["@type"])) {
      for (const child of refs(item.ownedMember)) if (index.get(child)?.kind === "PartUsage") add(id, child, "composition", `part:${id}:${child}`);
    }
    if (item["@type"]?.endsWith("Usage")) for (const type of refs(item.type)) add(id, type, "typing", `typing:${id}:${type}`);
    if (item["@type"] === "Documentation") for (const owner of refs(item.owner)) {
      const target = index.get(owner);
      if (target && !target.description) target.description = item.body || "";
    }
  }
  for (const view of views) {
    const nodes = new Map(view.nodes.map((n) => [n.id, n.semanticId]));
    for (const [i, edge] of view.edges.entries()) {
      const source = nodes.get(edge.fromId ?? edge.from ?? edge.source), target = nodes.get(edge.toId ?? edge.to ?? edge.target);
      add(source, target, edge.kind, `view:${view.id}:${i}`);
    }
  }
  const seen = /* @__PURE__ */ new Set();
  return { elements, relationships: relationships.filter((e) => {
    const key = JSON.stringify([e.source, e.target, e.kind]);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }) };
}
function graphView(graph, context, name = "Focused General View") {
  const known = new Map(graph.elements.map((e) => [e.id, e]));
  return { id: "explore:" + context.elements.map((e) => e.id).join(","), kind: "definition", title: name, omissions: context.omissions ?? [], nodes: context.elements.map((e) => ({ id: "gv:" + e.id, semanticId: e.id, name: e.name, kind: e.kind.replace(/(Usage|Definition)$/, "").replace(/([a-z])([A-Z])/g, "$1 $2").toLowerCase(), qualifiedName: e.qualifiedName, detail: e.description || "", type: refs(e.native?.type).map((id) => known.get(id)?.name || id).join(", ") })), edges: context.relationships.map((e) => ({ ...e, semanticSource: e.source, semanticTarget: e.target, source: "gv:" + e.source, target: "gv:" + e.target })) };
}
function requireNativeIdentity(view) {
  const missing = view.nodes.filter((n) => !n.semanticId && !["synthetic", "control", "notation"].includes(n.identityStatus));
  if (missing.length) throw Error("Native semantic identity missing for " + missing.map((n) => n.name || n.id).join(", "));
  return view;
}

// src/canvas-prototype/context.mjs
var allowedKinds2 = new Set(ENGINEERING_RELATIONSHIPS);
var forbiddenKinds = /* @__PURE__ */ new Set(["type", "typing", "specialization", "owner", "owningMembership", "ownedMembership", "documentation", "membership", "succession", "transition"]);
var engineeringElement = /^(Requirement|Part|Action|State|VerificationCase|AnalysisCase|UseCase|Case|Constraint|Calculation|Interface|Connection|Port|Attribute|Item|Occurrence|Allocation)(Definition|Usage)$/;
var compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
var edgeKey = (edge) => JSON.stringify([edge.id, edge.source, edge.target, edge.kind]);
var kindOrder = new Map(["derive", "derivation", "refine", "refinement", "satisfy", "satisfaction", "verify", "verification", "allocate", "allocation", "composition", "connection", "reference", "flow", "item-flow", "control-flow", "causation", "dependency"].map((kind, index) => [kind, index]));
function surroundingContext(graph, activeView, options = {}) {
  const { budget = 6 } = options;
  if (!Number.isInteger(budget) || budget < 0) throw new Error("Invalid surrounding context budget");
  const elements = new Map((graph.elements ?? []).map((element2) => [element2.id, element2]));
  const activeNodes = activeView.nodes ?? [], activeEdges = activeView.edges ?? [];
  const activeIds = [...new Set(activeNodes.map((node) => node.semanticId).filter(Boolean))].sort(compare);
  const active = new Set(activeIds), scope = options.scopeIds ? new Set(options.scopeIds) : null;
  const kinds = new Set((options.relationshipKinds ?? [...allowedKinds2]).filter((kind) => allowedKinds2.has(kind) && !forbiddenKinds.has(kind)));
  const representations = /* @__PURE__ */ new Map();
  for (const node of [...activeNodes].sort((a, b) => compare(a.id, b.id))) if (node.semanticId && !representations.has(node.semanticId)) representations.set(node.semanticId, node.id);
  const edges = [...new Map((graph.relationships ?? []).map((edge) => [edgeKey(edge), edge])).values()].sort((a, b) => compare(edgeKey(a), edgeKey(b)));
  const omissions = [], seenOmissions = /* @__PURE__ */ new Set();
  const omit = (edge, target, reason, anchor) => {
    const key = JSON.stringify([edgeKey(edge), target, reason]);
    if (seenOmissions.has(key)) return;
    seenOmissions.add(key);
    omissions.push({ relationshipId: edge.id ?? null, target, anchor, reason });
  };
  const elementReason = (id) => {
    const element2 = elements.get(id);
    if (!element2) return "unavailable";
    if (scope && !scope.has(id)) return "outside-scope";
    if (element2.layer === "metamodel" || element2.metamodel === true) return "metamodel-boundary";
    if (!engineeringElement.test(element2.kind ?? "")) return "element-policy";
    return null;
  };
  const candidates = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const sourceActive = active.has(edge.source), targetActive = active.has(edge.target);
    if (sourceActive === targetActive) continue;
    const target = sourceActive ? edge.target : edge.source, anchor = sourceActive ? edge.source : edge.target;
    const reason = !kinds.has(edge.kind) ? "relationship-policy" : elementReason(target);
    if (reason) {
      omit(edge, target, reason, anchor);
      continue;
    }
    if (!candidates.has(target)) candidates.set(target, []);
    candidates.get(target).push(edge);
  }
  const priority = (id) => Math.min(...candidates.get(id).map((edge) => kindOrder.get(edge.kind) ?? 99));
  const chosen = /* @__PURE__ */ new Set(), pending = new Map(activeIds.map((id) => [id, [...candidates.keys()].filter((target) => candidates.get(target).some((edge) => edge.source === id || edge.target === id)).sort((a, b) => priority(a) - priority(b) || compare(a, b))]));
  while (chosen.size < budget) {
    let progress = false;
    for (const id of activeIds) {
      const queue = pending.get(id);
      while (queue.length && chosen.has(queue[0])) queue.shift();
      if (queue.length && chosen.size < budget) {
        chosen.add(queue.shift());
        progress = true;
      }
    }
    if (!progress) break;
  }
  const relationships = [];
  for (const [target, links] of candidates) {
    if (chosen.has(target)) relationships.push(...links);
    else for (const edge of links) omit(edge, target, "budget", active.has(edge.source) ? edge.source : edge.target);
  }
  for (const edge of edges) if (chosen.has(edge.source) && chosen.has(edge.target)) {
    if (kinds.has(edge.kind)) relationships.push(edge);
    else omit(edge, edge.target, "relationship-policy", edge.source);
  }
  for (const edge of edges) {
    const sourceChosen = chosen.has(edge.source), targetChosen = chosen.has(edge.target);
    if (sourceChosen === targetChosen) continue;
    const target = sourceChosen ? edge.target : edge.source, anchor = sourceChosen ? edge.source : edge.target;
    if (active.has(target)) continue;
    const reason = !kinds.has(edge.kind) ? "relationship-policy" : elementReason(target) ?? "depth";
    omit(edge, target, reason, anchor);
  }
  const contextElements = [...chosen].map((id) => elements.get(id));
  const projected = graphView(graph, { elements: contextElements, relationships: [] }, "Surrounding engineering context");
  const contextIDs = new Map(contextElements.map((element2) => [element2.id, `context:${activeView.id ?? "view"}:${element2.id}`]));
  const endpoint2 = (id) => representations.get(id) ?? contextIDs.get(id);
  const byReason = {};
  for (const omission of omissions) byReason[omission.reason] = (byReason[omission.reason] ?? 0) + 1;
  const boundary = { omitted: omissions.length, byReason, budget, depth: 1, shown: contextElements.length };
  return {
    activeView,
    activeIds,
    activeNodes,
    activeEdges,
    elements: contextElements,
    relationships,
    omissions,
    boundary,
    view: {
      ...projected,
      id: `context:${activeView.id ?? "view"}`,
      kind: "general",
      context: true,
      fit: false,
      boundary,
      nodes: projected.nodes.map((node) => ({ ...node, id: contextIDs.get(node.semanticId), detail: "", type: "", parentId: null, context: true, fit: false, notation: "general" })),
      edges: relationships.map((edge) => ({ ...edge, id: `context:${edge.id ?? edgeKey(edge)}`, semanticSource: edge.source, semanticTarget: edge.target, source: endpoint2(edge.source), target: endpoint2(edge.target), context: true, fit: false, notation: "general" }))
    }
  };
}
var overlap = (a, b, gap = 0) => a.x < b.x + b.width + gap && a.x + a.width + gap > b.x && a.y < b.y + b.height + gap && a.y + a.height + gap > b.y;
var center = (rect) => ({ x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 });
var clamp = (value, min, max2) => Math.max(min, Math.min(max2, value));
function positionSurrounding(context, activePositionedNodes, area, options = {}) {
  const { width = 108, height = 52, gap = 12 } = options;
  if (![area?.x, area?.y, area?.width, area?.height, width, height, gap].every(Number.isFinite) || area.width <= 0 || area.height <= 0 || width <= 0 || height <= 0 || gap < 0) throw new Error("Invalid surrounding context geometry");
  const active = activePositionedNodes ?? [], known = new Map(active.map((node) => [node.id, node]));
  const left = area.x, top = area.y, right = left + area.width, bottom = top + area.height;
  const hull = active.length ? { x: Math.min(...active.map((n) => n.x)), y: Math.min(...active.map((n) => n.y)), width: Math.max(...active.map((n) => n.x + n.width)) - Math.min(...active.map((n) => n.x)), height: Math.max(...active.map((n) => n.y + n.height)) - Math.min(...active.map((n) => n.y)) } : area;
  const nodes = [], boundaryMarkers = [], omissions = [...context.omissions], occupied = [...active];
  const anchorFor = (node) => {
    const links = context.view.edges.filter((edge) => edge.source === node.id || edge.target === node.id);
    const anchors = links.map((edge) => known.get(edge.source === node.id ? edge.target : edge.source)).filter(Boolean);
    if (!anchors.length) return center(hull);
    return { x: anchors.reduce((sum, n) => sum + center(n).x, 0) / anchors.length, y: anchors.reduce((sum, n) => sum + center(n).y, 0) / anchors.length };
  };
  for (const [index, node] of context.view.nodes.entries()) {
    const anchor = anchorFor(node), candidatePoints = [];
    const xs = [left + gap, right - width - gap, clamp(anchor.x - width / 2, left + gap, right - width - gap)], ys = [top + gap, bottom - height - gap, clamp(anchor.y - height / 2, top + gap, bottom - height - gap)];
    for (const activeNode of active) {
      xs.push(activeNode.x - width - gap, activeNode.x + activeNode.width + gap);
      ys.push(activeNode.y - height - gap, activeNode.y + activeNode.height + gap);
    }
    for (const x of xs) for (const y of ys) {
      const candidate = { x, y, width, height };
      if (x < left || y < top || x + width > right || y + height > bottom) continue;
      if (occupied.some((other) => overlap(candidate, other, gap))) continue;
      candidatePoints.push(candidate);
    }
    candidatePoints.sort((a, b) => Number(overlap(a, hull)) - Number(overlap(b, hull)) || Math.hypot(center(a).x - anchor.x, center(a).y - anchor.y) - Math.hypot(center(b).x - anchor.x, center(b).y - anchor.y) || a.y - b.y || a.x - b.x);
    if (candidatePoints.length) {
      const placed = { ...node, ...candidatePoints[0] };
      nodes.push(placed);
      occupied.push(placed);
      continue;
    }
    const points = [{ x: left, y: clamp(anchor.y, top, bottom) }, { x: right, y: clamp(anchor.y, top, bottom) }, { x: clamp(anchor.x, left, right), y: top }, { x: clamp(anchor.x, left, right), y: bottom }];
    points.sort((a, b) => Math.hypot(a.x - anchor.x, a.y - anchor.y) - Math.hypot(b.x - anchor.x, b.y - anchor.y) || a.y - b.y || a.x - b.x);
    const point = points[index % points.length];
    boundaryMarkers.push({ ...node, ...point, width: 0, height: 0, kind: "context-boundary", boundary: true, interactive: false });
    const link = context.view.edges.find((edge) => edge.source === node.id || edge.target === node.id);
    omissions.push({ target: node.semanticId, anchor: link ? link.semanticSource === node.semanticId ? link.semanticTarget : link.semanticSource : null, reason: "context-space", relationshipId: link?.id ?? null });
  }
  const byReason = {};
  for (const omission of omissions) byReason[omission.reason] = (byReason[omission.reason] ?? 0) + 1;
  return { ...context.view, nodes, edges: context.view.edges, boundaryMarkers, omissions, boundary: { ...context.boundary, omitted: omissions.length, byReason, cards: nodes.length, markers: boundaryMarkers.length } };
}

// src/canvas-prototype/motion.mjs
function sampleTrack(track, offsets, progress) {
  if (progress <= 0) return { ...track[0] };
  if (progress >= 1) return { ...track.at(-1) };
  let i = 0;
  while (i < offsets.length - 2 && progress > offsets[i + 1]) i++;
  const t = (progress - offsets[i]) / (offsets[i + 1] - offsets[i]), a = track[i], b = track[i + 1], result = {};
  for (const key of Object.keys(a)) {
    if (typeof a[key] !== "number") {
      result[key] = t < 0.5 ? a[key] : b[key];
      continue;
    }
    const derivative = (index) => {
      const slope = (j) => (track[j + 1][key] - track[j][key]) / (offsets[j + 1] - offsets[j]);
      if (index === 0) return slope(0);
      if (index === track.length - 1) return slope(index - 1);
      const left = slope(index - 1), right = slope(index);
      if (left * right <= 0) return 0;
      const h0 = offsets[index] - offsets[index - 1], h1 = offsets[index + 1] - offsets[index], w0 = 2 * h1 + h0, w1 = h1 + 2 * h0;
      return (w0 + w1) / (w0 / left + w1 / right);
    };
    const width = offsets[i + 1] - offsets[i], m0 = derivative(i) * width, m1 = derivative(i + 1) * width;
    const value = (2 * t ** 3 - 3 * t ** 2 + 1) * a[key] + (t ** 3 - 2 * t ** 2 + t) * m0 + (-2 * t ** 3 + 3 * t ** 2) * b[key] + (t ** 3 - t ** 2) * m1;
    result[key] = Math.max(Math.min(a[key], b[key]), Math.min(Math.max(a[key], b[key]), value));
  }
  return result;
}
var easeJourney = (t) => (1 - Math.cos(Math.PI * Math.max(0, Math.min(1, t)))) / 2;
function startTimeline({ duration, update, request = (fn) => requestAnimationFrame(fn), cancel = (id) => cancelAnimationFrame(id), now = () => performance.now() }) {
  let handle, stopped = false, resolve2;
  const finished = new Promise((r) => resolve2 = r), start2 = now();
  const finish = (cancelled) => {
    if (stopped) return;
    stopped = true;
    if (handle !== void 0) cancel(handle);
    resolve2({ cancelled });
  };
  const tick = (time) => {
    if (stopped) return;
    const t = Math.min(1, Math.max(0, (time - start2) / duration));
    update(easeJourney(t), t);
    if (t >= 1) finish(false);
    else handle = request(tick);
  };
  if (duration <= 0) {
    update(1, 1);
    finish(false);
  } else {
    update(0, 0);
    handle = request(tick);
  }
  return { finished, cancel: () => finish(true), finish: () => {
    if (!stopped) {
      update(1, 1);
      finish(false);
    }
  } };
}
function samplePolyline(points, count = 20) {
  const lengths = [0];
  for (let i = 1; i < points.length; i++) lengths.push(lengths.at(-1) + Math.hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y));
  const total = lengths.at(-1);
  return Array.from({ length: count }, (_, i) => {
    const distance = total * i / (count - 1);
    let j = 1;
    while (j < lengths.length - 1 && lengths[j] < distance) j++;
    const amount = (distance - lengths[j - 1]) / (lengths[j] - lengths[j - 1] || 1);
    return { x: points[j - 1].x + (points[j].x - points[j - 1].x) * amount, y: points[j - 1].y + (points[j].y - points[j - 1].y) * amount };
  });
}
function visibleTrackKeys(frames, collection) {
  return [...new Set(frames.flatMap((frame2) => frame2[collection].filter((item) => (item.opacity ?? 1) > 0).map((item) => item.key)))];
}

// src/canvas-prototype/documentation.mjs
var indexes = /* @__PURE__ */ new WeakMap();
function documentationFor(graph, id) {
  let index = indexes.get(graph);
  if (!index) {
    index = new Map((graph?.elements ?? []).map((e) => [e.id, e]));
    if (graph) indexes.set(graph, index);
  }
  const own = index.get(id);
  if (own?.description) return { text: own.description, source: own };
  const types = own?.native?.type;
  const references = Array.isArray(types) ? types : types ? [types] : [];
  for (const reference of references) {
    const type = index.get(reference?.["@id"]);
    if (type?.description) return { text: type.description, source: type };
  }
  return { text: "", source: own };
}
function measureCard(document2, node, detail) {
  const width = Math.max(Number(node.width) || 0, detail ? 280 : 160);
  const card = document2.createElement("div");
  card.className = "node";
  card.style.cssText = `position:fixed;left:-10000px;top:0;visibility:hidden;width:${width}px;height:auto;transform:none;`;
  for (const [className, text] of [["kind", `\xAB${node.kind}\xBB${node.displayID ? " " + node.displayID : ""}${node.type ? " : " + node.type : ""}`], ["name", (node.name?.split("::").at(-1) || node.kind).replace(/([a-z0-9])([A-Z])/g, "$1\u200B$2")], ...detail ? [["detail", detail]] : []]) {
    const part = document2.createElement("span");
    part.className = className;
    part.textContent = text;
    card.append(part);
  }
  document2.body.append(card);
  const height = Math.max(76, Math.ceil(card.getBoundingClientRect().height), card.scrollHeight);
  card.remove();
  return { width, height };
}

// src/canvas-prototype/geometry.mjs
var overlaps = (a, b, gap = 0) => a.x < b.x + b.width + gap && a.x + a.width + gap > b.x && a.y < b.y + b.height + gap && a.y + a.height + gap > b.y;
var centre = (n) => ({ x: n.x + n.width / 2, y: n.y + n.height / 2 });
function graphArea(width, height, panels = []) {
  const left = 16, top = 16, right = Math.max(left + 1, width - 16), bottom = Math.max(top + 1, height - 60);
  const xs = [left, right, ...panels.flatMap((p) => [Math.max(left, p.x - 16), Math.min(right, p.x + p.width + 16)])];
  const ys = [top, bottom, ...panels.flatMap((p) => [Math.max(top, p.y - 16), Math.min(bottom, p.y + p.height + 16)])];
  const candidates = [];
  for (const x of xs) for (const r of xs) for (const y of ys) for (const b of ys) {
    const rect = { x, y, width: r - x, height: b - y };
    if (rect.width > 0 && rect.height > 0 && !panels.some((p) => overlaps(rect, p))) candidates.push(rect);
  }
  return candidates.sort((a, b) => b.width * b.height - a.width * a.height)[0] ?? { x: left, y: top, width: right - left, height: bottom - top };
}
function fitNodes(nodes, area) {
  const minX = nodes.length ? Math.min(...nodes.map((n) => n.x)) : 0, minY = nodes.length ? Math.min(...nodes.map((n) => n.y)) : 0;
  const maxX = nodes.length ? Math.max(...nodes.map((n) => n.x + n.width)) : 1, maxY = nodes.length ? Math.max(...nodes.map((n) => n.y + n.height)) : 1;
  const scale = Math.min(1.4, area.width / (maxX - minX + 20), area.height / (maxY - minY + 20));
  const offsetX = area.x + (area.width - (maxX - minX) * scale) / 2 - minX * scale, offsetY = area.y + (area.height - (maxY - minY) * scale) / 2 - minY * scale;
  return { scale, nodes: nodes.map((n) => ({ ...n, x: n.x * scale + offsetX, y: n.y * scale + offsetY, width: n.width * scale, height: n.height * scale })) };
}
var simplify = (points) => points.filter((p, i) => !i || p.x !== points[i - 1].x || p.y !== points[i - 1].y).filter((p, i, all) => !i || i === all.length - 1 || !(all[i - 1].x === p.x && p.x === all[i + 1].x || all[i - 1].y === p.y && p.y === all[i + 1].y));
function segmentBlocked(a, b, obstacles) {
  return obstacles.some((n) => a.x === b.x ? a.x > n.x && a.x < n.x + n.width && Math.max(a.y, b.y) > n.y && Math.min(a.y, b.y) < n.y + n.height : a.y > n.y && a.y < n.y + n.height && Math.max(a.x, b.x) > n.x && Math.min(a.x, b.x) < n.x + n.width);
}
function orthogonal(start2, end, obstacles) {
  const xs = [.../* @__PURE__ */ new Set([start2.x, end.x, ...obstacles.flatMap((n) => [n.x, n.x + n.width])])].sort((a, b) => a - b);
  const ys = [.../* @__PURE__ */ new Set([start2.y, end.y, ...obstacles.flatMap((n) => [n.y, n.y + n.height])])].sort((a, b) => a - b);
  const points = [], byXY = /* @__PURE__ */ new Map();
  for (const x of xs) for (const y of ys) if (!obstacles.some((n) => x > n.x && x < n.x + n.width && y > n.y && y < n.y + n.height)) {
    byXY.set(x + "," + y, points.length);
    points.push({ x, y });
  }
  const first = byXY.get(start2.x + "," + start2.y), last = byXY.get(end.x + "," + end.y);
  if (first === void 0 || last === void 0) return null;
  const links = points.map(() => []);
  for (const axis of ["x", "y"]) {
    const groups = /* @__PURE__ */ new Map();
    for (const [i, p] of points.entries()) {
      const value = p[axis];
      if (!groups.has(value)) groups.set(value, []);
      groups.get(value).push(i);
    }
    for (const group of groups.values()) {
      group.sort((a, b) => points[a][axis === "x" ? "y" : "x"] - points[b][axis === "x" ? "y" : "x"]);
      for (let j = 1; j < group.length; j++) {
        const a = group[j - 1], b = group[j];
        if (!segmentBlocked(points[a], points[b], obstacles)) {
          const length = Math.abs(points[a].x - points[b].x) + Math.abs(points[a].y - points[b].y);
          links[a].push([b, length, axis]);
          links[b].push([a, length, axis]);
        }
      }
    }
  }
  const queue = [{ id: first, cost: 0, axis: "", path: [first] }], best = /* @__PURE__ */ new Map();
  while (queue.length) {
    queue.sort((a, b) => a.cost - b.cost);
    const current = queue.shift(), key = current.id + current.axis;
    if (best.has(key) && best.get(key) < current.cost) continue;
    if (current.id === last) return current.path.map((i) => points[i]);
    for (const [id, length, axis] of links[current.id]) {
      const cost = current.cost + length + (current.axis && current.axis !== axis ? 14 : 0), key2 = id + axis;
      if (best.has(key2) && best.get(key2) <= cost) continue;
      best.set(key2, cost);
      queue.push({ id, cost, axis, path: [...current.path, id] });
    }
  }
  return null;
}
function endpoints(a, b, sourceFraction = 0.5, targetFraction = 0.5) {
  const ac = centre(a), bc = centre(b), vertical = Math.abs(ac.y - bc.y) > Math.abs(ac.x - bc.x) * 0.5;
  const normal = (side) => ({ NORTH: { x: 0, y: -1 }, SOUTH: { x: 0, y: 1 }, EAST: { x: 1, y: 0 }, WEST: { x: -1, y: 0 } })[side];
  const defaultDirection = vertical ? { x: 0, y: bc.y > ac.y ? 1 : -1 } : { x: bc.x > ac.x ? 1 : -1, y: 0 };
  const sourceDirection = normal(a.kind === "port" ? a.portSide ?? a.side : "") ?? defaultDirection, targetDirection = normal(b.kind === "port" ? b.portSide ?? b.side : "") ?? { x: -defaultDirection.x, y: -defaultDirection.y };
  const attachment = (node, direction, fraction) => direction.x ? { x: node.x + (direction.x > 0 ? node.width : 0), y: node.y + node.height * fraction } : { x: node.x + node.width * fraction, y: node.y + (direction.y > 0 ? node.height : 0) };
  return [attachment(a, sourceDirection, sourceFraction), attachment(b, targetDirection, targetFraction), sourceDirection, targetDirection];
}
function connectionObstacles(edge, nodes) {
  const byID = new Map(nodes.map((n) => [n.id, n])), ancestors = /* @__PURE__ */ new Set(), leafPortOwners = /* @__PURE__ */ new Set();
  for (const id of [edge.source, edge.target]) {
    let node = byID.get(id);
    if (node?.kind === "port" && node.parentId && !byID.get(node.parentId)?.headerHeight) leafPortOwners.add(node.parentId);
    const seen = /* @__PURE__ */ new Set();
    while (node?.parentId && !seen.has(node.parentId)) {
      seen.add(node.parentId);
      ancestors.add(node.parentId);
      node = byID.get(node.parentId);
    }
  }
  return nodes.filter((n) => (n.opacity ?? 1) > 0.08 && n.width > 0 && n.height > 0).flatMap((n) => ancestors.has(n.id) && !leafPortOwners.has(n.id) ? n.headerHeight ? [{ ...n, height: n.headerHeight }] : [] : [n]);
}
function route(a, b, nodes, options = {}) {
  const [start2, end, direction, targetDirection] = endpoints(a, b, options.sourceFraction, options.targetFraction), clearance = options.clearance ?? 8;
  let stub = { x: start2.x + direction.x * clearance, y: start2.y + direction.y * clearance }, finish = { x: end.x + targetDirection.x * clearance, y: end.y + targetDirection.y * clearance };
  const obstacles = connectionObstacles({ source: a.id, target: b.id }, nodes).map((n) => ({ x: n.x - 4, y: n.y - 4, width: n.width + 8, height: n.height + 8 }));
  let middle = orthogonal(stub, finish, obstacles);
  if (!middle && clearance > 4.1) {
    stub = { x: start2.x + direction.x * 4.1, y: start2.y + direction.y * 4.1 };
    finish = { x: end.x + targetDirection.x * 4.1, y: end.y + targetDirection.y * 4.1 };
    middle = orthogonal(stub, finish, obstacles);
  }
  const points = middle ? simplify([start2, ...middle, end]) : [];
  return { points, d: points.map((p, i) => (i ? "L" : "M") + p.x + "," + p.y).join(" "), routingBlocked: !middle };
}
function lineCrossesRect(a, b, rect, padding = 0) {
  const left = rect.x - padding, top = rect.y - padding, right = rect.x + rect.width + padding, bottom = rect.y + rect.height + padding;
  let lo = 0, hi = 1;
  for (const [origin, delta, min, max2] of [[a.x, b.x - a.x, left, right], [a.y, b.y - a.y, top, bottom]]) {
    if (Math.abs(delta) < 1e-9) {
      if (origin <= min || origin >= max2) return false;
      continue;
    }
    let first = (min - origin) / delta, last = (max2 - origin) / delta;
    if (first > last) [first, last] = [last, first];
    lo = Math.max(lo, first);
    hi = Math.min(hi, last);
    if (lo >= hi) return false;
  }
  return hi > 0 && lo < 1;
}
function clearLeader(box, points, nodes, labels) {
  const from = { x: box.x + box.width / 2, y: box.y + box.height / 2 }, targets = [...points, ...points.slice(1).map((p, i) => ({ x: (p.x + points[i].x) / 2, y: (p.y + points[i].y) / 2 }))];
  targets.sort((a, b) => Math.hypot(a.x - from.x, a.y - from.y) - Math.hypot(b.x - from.x, b.y - from.y));
  const to = targets.find((target) => !nodes.some((n) => n.width > 0 && n.height > 0 && lineCrossesRect(from, target, n, 2)) && !labels.some((label2) => lineCrossesRect(from, target, label2, 2)));
  return to ? { from, to } : null;
}
function labelCandidates(points, width, height) {
  const candidates = [];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i], length = Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
    if (length < 8) continue;
    for (const t of [0.5, 0.25, 0.75]) {
      const x = a.x + (b.x - a.x) * t, y = a.y + (b.y - a.y) * t;
      if (a.y === b.y) {
        candidates.push({ x: x - width / 2, y: y - height - 3, score: length }, { x: x - width / 2, y: y + 3, score: length - 1 });
      } else candidates.push({ x: x + 5, y: y - height / 2, score: length - 2 }, { x: x - width - 5, y: y - height / 2, score: length - 3 });
    }
  }
  return candidates.sort((a, b) => b.score - a.score);
}
function routeEdges(edges, nodes, options = {}) {
  const byID = new Map(nodes.map((n) => [n.id, n])), labels = [], ports = /* @__PURE__ */ new Map();
  const measured = (text) => {
    const size = options.measureLabel?.(text);
    return { width: Math.max(1, size?.width ?? String(text).length * 7.2 + 4), height: Math.max(1, size?.height ?? 16) };
  };
  const ordered = [...edges].sort((a, b) => String(a.id).localeCompare(String(b.id)));
  for (const edge of ordered) for (const side of ["source", "target"]) {
    const key = edge[side];
    if (!ports.has(key)) ports.set(key, []);
    ports.get(key).push({ edge, side });
  }
  const fraction = (edge, side) => {
    const group = ports.get(edge[side]), index = group.findIndex((item) => item.edge === edge && item.side === side);
    return group.length === 1 ? 0.5 : 0.2 + 0.6 * (index + 0.5) / group.length;
  };
  const area = options.area;
  return edges.map((edge) => {
    const a = byID.get(edge.source), b = byID.get(edge.target);
    if (!a || !b) return null;
    const result = { ...edge, ...route(a, b, nodes, { ...options, sourceFraction: fraction(edge, "source"), targetFraction: fraction(edge, "target") }) };
    if (!edge.label || result.routingBlocked) return result;
    const size = measured(edge.label), valid = (box) => !nodes.some((n) => n.width > 0 && n.height > 0 && overlaps(box, n, 3)) && !labels.some((other) => overlaps(box, other, 4)) && (!area || box.x >= area.x && box.y >= area.y && box.x + box.width <= area.x + area.width && box.y + box.height <= area.y + area.height);
    let labelBox = labelCandidates(result.points, size.width, size.height).map((candidate) => ({ ...candidate, ...size })).find(valid);
    if (!labelBox) {
      const mid = result.points[1] ?? result.points[0], region = area ?? { x: Math.min(...nodes.map((n) => n.x)) - 80, y: Math.min(...nodes.map((n) => n.y)) - 40, width: Math.max(...nodes.map((n) => n.x + n.width)) - Math.min(...nodes.map((n) => n.x)) + 160, height: Math.max(...nodes.map((n) => n.y + n.height)) - Math.min(...nodes.map((n) => n.y)) + 80 };
      const cards = nodes.filter((n) => n.width > 0 && n.height > 0);
      const xs = [region.x, ...cards.flatMap((n) => [n.x + n.width / 2 - size.width / 2, n.x - size.width - 4, n.x + n.width + 4]), ...result.points.map((p) => p.x - size.width / 2)];
      const ys = [region.y, ...cards.flatMap((n) => [n.y + n.height + 4, n.y - size.height - 4]), ...result.points.map((p) => p.y - size.height / 2)];
      for (let y = region.y; y + size.height <= region.y + region.height; y += size.height + 5) ys.push(y);
      for (let x = region.x; x + size.width <= region.x + region.width; x += Math.max(12, size.width / 2)) xs.push(x);
      const slots = [];
      for (const y of new Set(ys)) for (const x of new Set(xs)) {
        const box = { x, y, ...size };
        if (valid(box)) slots.push(box);
      }
      slots.sort((a2, b3) => Math.hypot(a2.x + a2.width / 2 - mid.x, a2.y + a2.height / 2 - mid.y) - Math.hypot(b3.x + b3.width / 2 - mid.x, b3.y + b3.height / 2 - mid.y));
      for (const slot of slots) {
        const leader = clearLeader(slot, result.points, nodes, labels);
        if (leader) {
          labelBox = slot;
          result.labelLeader = leader;
          break;
        }
      }
    }
    if (labelBox) {
      labels.push(labelBox);
      result.labelBox = labelBox;
      result.x = labelBox.x;
      result.y = labelBox.y + labelBox.height * 0.78;
    } else result.labelOmitted = true;
    return result;
  }).filter(Boolean);
}
function fitDiagram(layout, area) {
  const occupied = [...layout.nodes, ...layout.nodes.flatMap((n) => n.portLabelBox ? [n.portLabelBox] : []), ...layout.edges.flatMap((e) => [...e.labelBox ? [e.labelBox] : [], ...e.points.map((p) => ({ ...p, width: 0, height: 0 }))])], fit = fitNodes(occupied, area), scale = fit.scale;
  const origin = occupied[0], fitted = fit.nodes[0], dx = origin ? fitted.x - origin.x * scale : area.x, dy = origin ? fitted.y - origin.y * scale : area.y;
  const point = (p) => ({ x: p.x * scale + dx, y: p.y * scale + dy }), box = (n) => ({ ...n, ...point(n), width: n.width * scale, height: n.height * scale });
  return { ...layout, scale, nodes: layout.nodes.map((n) => ({ ...box(n), ...n.headerHeight ? { headerHeight: n.headerHeight * scale } : {}, ...n.portLabelBox ? { portLabelBox: box(n.portLabelBox) } : {} })), edges: layout.edges.map((e) => ({ ...e, points: e.points.map(point), ...e.labelBox ? { labelBox: box(e.labelBox), x: e.x * scale + dx, y: e.y * scale + dy } : {}, labelScale: scale })), ports: layout.ports?.map((p) => ({ ...p, ...point(p) })) };
}
function routeIsClear(points, edge, nodes, { orthogonalOnly = false } = {}) {
  if (points.length < 2 || points.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y))) return false;
  const obstacles = connectionObstacles(edge, nodes);
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i];
    if (orthogonalOnly && Math.abs(a.x - b.x) > 0.01 && Math.abs(a.y - b.y) > 0.01) return false;
    if (obstacles.some((n) => lineCrossesRect(a, b, { x: n.x + 0.05, y: n.y + 0.05, width: Math.max(0, n.width - 0.1), height: Math.max(0, n.height - 0.1) }))) return false;
  }
  return true;
}

// src/canvas-prototype/elk-layout.mjs
var import_elk_api = __toESM(require_elk_api(), 1);

// src/canvas-prototype/notation.mjs
var profiles = Object.freeze({
  connection: ["solid", "none", "none", false, "connector"],
  transition: ["solid", "none", "filled-arrow", true, "behavior"],
  succession: ["solid", "none", "filled-arrow", true, "behavior"],
  flow: ["dashed", "none", "filled-arrow", true, "behavior"],
  binding: ["solid", "none", "none", false, "connector"],
  specialization: ["solid", "none", "hollow-triangle", true, "classifier"],
  typing: ["dashed", "none", "hollow-triangle", true, "classifier"],
  composition: ["solid", "diamond", "none", true, "ownership"],
  reference: ["solid", "hollow-diamond", "none", true, "ownership"],
  containment: ["solid", "containment", "none", true, "ownership"],
  import: ["dashed", "none", "open-arrow", true, "dependency"],
  satisfy: ["dashed", "none", "open-arrow", true, "dependency"],
  verify: ["dashed", "none", "open-arrow", true, "dependency"],
  derive: ["dashed", "none", "open-arrow", true, "derivation"],
  refine: ["dashed", "none", "open-arrow", true, "dependency"],
  allocate: ["dashed", "none", "open-arrow", true, "dependency"],
  association: ["solid", "none", "none", false, "connector"],
  include: ["dashed", "none", "filled-arrow", true, "dependency"],
  anchor: ["dashed", "none", "none", false, "annotation"],
  dependency: ["dashed", "none", "open-arrow", true, "dependency"]
});
function edgeAppearance(edge, { viewKind = edge.viewKind } = {}) {
  const profile = Object.hasOwn(profiles, edge.kind) ? profiles[edge.kind] : null;
  if (!profile) return {
    line: "solid",
    sourceMarker: "none",
    targetMarker: "none",
    directed: false,
    label: edge.label ?? "",
    supported: false,
    family: "unsupported",
    notice: `Unsupported relationship notation: ${String(edge.kind ?? "(missing kind)")}. Shown as a neutral line; direction is not inferred.`
  };
  let [line, sourceMarker, targetMarker, directed, family] = profile;
  if (["case", "mixed"].includes(viewKind) && ["typing", "reference"].includes(edge.kind)) {
    line = "dashed";
    sourceMarker = "none";
    targetMarker = "open-arrow";
    directed = true;
    family = "dependency";
  }
  return {
    line,
    sourceMarker,
    targetMarker,
    directed,
    family,
    label: edge.label ?? "",
    supported: true,
    notice: ""
  };
}
function edgeLayoutHints(edge, options) {
  const appearance = edgeAppearance(edge, options);
  const caseReference = appearance.family === "dependency" && edge.kind === "reference";
  const rank = ["specialization", "typing", "derive"].includes(edge.kind) ? "target-above-source" : ["composition", "containment", "reference"].includes(edge.kind) && !caseReference ? "source-above-target" : ["transition", "succession", "flow"].includes(edge.kind) ? "source-before-target" : "free";
  return {
    family: appearance.family,
    rank,
    preserveEndpoints: true,
    supported: appearance.supported
  };
}
function markerDefinition(name) {
  const common = {
    viewBox: "0 0 12 12",
    refX: 11,
    refY: 6,
    markerWidth: 12,
    markerHeight: 12,
    orient: "auto-start-reverse"
  };
  switch (name) {
    case "open-arrow":
      return { ...common, path: "M1,1 L11,6 L1,11", fill: "none" };
    case "filled-arrow":
      return { ...common, path: "M1,1 L11,6 L1,11 Z", fill: "line" };
    case "hollow-triangle":
      return { ...common, path: "M1,1 L11,6 L1,11 Z", fill: "background" };
    case "diamond":
      return { ...common, path: "M1,6 L6,1 L11,6 L6,11 Z", fill: "line" };
    case "hollow-diamond":
      return { ...common, path: "M1,6 L6,1 L11,6 L6,11 Z", fill: "background" };
    case "containment":
      return { ...common, path: "M11,6 A5,5 0 1,1 1,6 A5,5 0 1,1 11,6 Z", fill: "background" };
    case "continuation-chevron":
      return { ...common, path: "M2,1 L7,6 L2,11 M6,1 L11,6 L6,11", fill: "none" };
    default:
      return null;
  }
}

// src/canvas-prototype/elk-layout.mjs
var createLayoutEngine = (options) => new import_elk_api.default({ algorithms: ["layered"], ...options });
var behavioralKinds = /* @__PURE__ */ new Set(["action", "activity", "state"]);
var sizes = /* @__PURE__ */ new Map([["initial", [28, 28]], ["final", [32, 32]], ["fork", [80, 8]], ["join", [80, 8]], ["decision", [44, 44]], ["merge", [44, 44]], ["start", [28, 28]], ["end", [32, 32]]]);
var overlap2 = (a, b, gap = 0) => a.x < b.x + b.width + gap && a.x + a.width + gap > b.x && a.y < b.y + b.height + gap && a.y + a.height + gap > b.y;
var segmentHits = (a, b, n) => a.x === b.x ? a.x > n.x + 0.01 && a.x < n.x + n.width - 0.01 && Math.max(a.y, b.y) > n.y + 0.01 && Math.min(a.y, b.y) < n.y + n.height - 0.01 : a.y === b.y && a.y > n.y + 0.01 && a.y < n.y + n.height - 0.01 && Math.max(a.x, b.x) > n.x + 0.01 && Math.min(a.x, b.x) < n.x + n.width - 0.01;
var simplify2 = (points) => points.filter((p, i) => !i || p.x !== points[i - 1].x || p.y !== points[i - 1].y).filter((p, i, all) => !i || i === all.length - 1 || !(all[i - 1].x === p.x && p.x === all[i + 1].x || all[i - 1].y === p.y && p.y === all[i + 1].y));
var num = (value, fallback) => Number.isFinite(Number(value)) && Number(value) > 0 ? Number(value) : fallback;
function dimensions(node) {
  const symbol = sizes.get(node.kind);
  return { width: symbol?.[0] ?? num(node.width, 160), height: symbol?.[1] ?? num(node.height, 76) };
}
function isPort(node, nodes) {
  return node.kind === "port" && nodes.has(node.parentId);
}
function projectEmbeddedPorts(view) {
  const nodes = [...view.nodes], attachments = /* @__PURE__ */ new Map(), usedIDs = new Set(nodes.map((n) => n.id));
  for (const owner of view.nodes) for (const port of owner.ports ?? []) {
    if (typeof port.id !== "string" || !port.id) throw Error("Native embedded port lacks a rendering ID");
    const key = JSON.stringify([owner.id, port.id]);
    if (attachments.has(key)) throw Error("Duplicate native port on " + owner.id + ": " + port.id);
    let id = "syspresent-native-port:" + key;
    while (usedIDs.has(id)) id += ":";
    usedIDs.add(id);
    attachments.set(key, id);
    const name = port.nameSynthesized ? "" : port.name ?? "", label2 = port.type ? name + " : " + port.type : name;
    nodes.push({ id, kind: "port", name, label: label2, parentId: owner.id, width: 12, height: 12, semanticId: null, identityStatus: "modeled-pin", nativePortId: port.id, nativePort: structuredClone(port), direction: port.direction, parameter: port.parameter, origin: structuredClone(port.origin ?? null) });
  }
  const edges = view.edges.map((edge) => {
    const result = { ...edge };
    for (const [endpoint2, field, attachment] of [["source", "fromPort", "sourceAttachment"], ["target", "toPort", "targetAttachment"]]) {
      const pin = edge[field] ?? edge[field === "fromPort" ? "from_port" : "to_port"];
      if (!pin) continue;
      const id = attachments.get(JSON.stringify([edge[endpoint2], pin]));
      if (!id) throw Error("Native connection " + edge.id + " references unavailable port " + pin + " on " + edge[endpoint2]);
      result[attachment] = id;
    }
    return result;
  });
  return { ...view, nodes, edges };
}
function orientation(edge, behavioral, viewKind) {
  return !behavioral && edgeLayoutHints(edge, { viewKind }).rank === "target-above-source" ? [edge.target, edge.source, true] : [edge.source, edge.target, false];
}
function partitions(nodes, edges, capacity) {
  const ranks = new Map(nodes.map((n) => [n.id, 0]));
  for (let i = 0; i < nodes.length; i++) {
    let changed = false;
    for (const [a, b] of edges) {
      if (a !== b && ranks.has(a) && ranks.has(b) && ranks.get(b) <= ranks.get(a)) {
        ranks.set(b, ranks.get(a) + 1);
        changed = true;
      }
    }
    if (!changed) break;
    if (i === nodes.length - 1) return null;
  }
  const groups = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    const rank = ranks.get(node.id);
    if (!groups.has(rank)) groups.set(rank, []);
    groups.get(rank).push(node);
  }
  const result = /* @__PURE__ */ new Map();
  let row = 0;
  for (const [, group] of [...groups].sort((a, b) => a[0] - b[0])) {
    group.sort((a, b) => a.id.localeCompare(b.id));
    for (let i = 0; i < group.length; i++) result.set(group[i].id, row + Math.floor(i / capacity));
    row += Math.ceil(group.length / capacity);
  }
  return result;
}
function makeGraph(view, options, profile) {
  const nodes = new Map(view.nodes.map((n) => [n.id, n])), behavioral = behavioralKinds.has(view.kind), actualPorts = new Set(view.nodes.filter((n) => isPort(n, nodes)).map((n) => n.id)), children = new Map(view.nodes.map((n) => [n.id, []]));
  for (const node of view.nodes) if (node.parentId && nodes.has(node.parentId) && !actualPorts.has(node.id)) children.get(node.parentId).push(node.id);
  const roots = view.nodes.filter((n) => !actualPorts.has(n.id) && (!n.parentId || !nodes.has(n.parentId)));
  const rootOf = (id) => {
    let node = nodes.get(id), seen = /* @__PURE__ */ new Set();
    while (node?.parentId && nodes.has(node.parentId)) {
      if (seen.has(node.id)) throw Error("Cyclic native drawing containment");
      seen.add(node.id);
      node = nodes.get(node.parentId);
    }
    return node?.id;
  };
  const rows = profile.capacity ? partitions(roots, view.edges.filter((e) => edgeLayoutHints(e, { viewKind: view.kind }).rank !== "free").map((e) => {
    const [a, b] = orientation(e, behavioral, view.kind);
    return [rootOf(a), rootOf(b)];
  }), profile.capacity) : null;
  const elkNodes = /* @__PURE__ */ new Map(), anchors = /* @__PURE__ */ new Map(), edgeMap = /* @__PURE__ */ new Map(), gap = profile.gap;
  function build(node) {
    const { width, height } = dimensions(node), nested = children.get(node.id), result = { id: node.id, width, height, children: nested.map((id) => build(nodes.get(id))), ports: [], layoutOptions: { "elk.portConstraints": "FIXED_SIDE", "elk.portLabels.placement": "[OUTSIDE]", "elk.padding": `[top=${height + 20},left=24,bottom=24,right=24]` } };
    if (!nested.length) delete result.children;
    if (rows?.has(node.id)) result.layoutOptions["elk.partitioning.partition"] = String(rows.get(node.id));
    elkNodes.set(node.id, result);
    return result;
  }
  const graph = { id: "syspresent-layout-root", children: roots.map(build), edges: [], layoutOptions: {
    "elk.algorithm": "layered",
    "elk.direction": "DOWN",
    "elk.edgeRouting": "ORTHOGONAL",
    "elk.hierarchyHandling": "INCLUDE_CHILDREN",
    "elk.randomSeed": "1",
    "elk.padding": "[top=12,left=12,bottom=12,right=12]",
    "elk.spacing.nodeNode": String(gap),
    "elk.spacing.edgeEdge": "12",
    "elk.spacing.edgeNode": "12",
    "elk.spacing.labelNode": "8",
    "elk.spacing.edgeLabel": "7",
    "elk.layered.spacing.nodeNodeBetweenLayers": String(gap),
    "elk.layered.spacing.edgeEdgeBetweenLayers": "12",
    "elk.layered.spacing.edgeNodeBetweenLayers": "12",
    "elk.layered.mergeEdges": "false",
    "elk.layered.mergeHierarchyEdges": "false",
    "elk.layered.unnecessaryBendpoints": "true",
    "elk.layered.crossingMinimization.strategy": "LAYER_SWEEP",
    "elk.layered.nodePlacement.strategy": profile.capacity ? "SIMPLE" : "BRANDES_KOEPF",
    ...rows ? { "elk.partitioning.activate": "true" } : {}
  } };
  for (const native of view.nodes.filter((n) => actualPorts.has(n.id))) {
    const owner = elkNodes.get(native.parentId), incoming = view.edges.find((e) => (e.sourceAttachment ?? e.source) === native.id || (e.targetAttachment ?? e.target) === native.id), specified = String(native.portSide ?? native.side ?? "").toUpperCase();
    const side = ["NORTH", "SOUTH", "EAST", "WEST"].includes(specified) ? specified : (incoming?.sourceAttachment ?? incoming?.source) === native.id ? "SOUTH" : "NORTH";
    const text = native.label ?? native.name, label2 = text ? options.measureLabel?.(text) ?? { width: String(text).length * 6.5, height: 16 } : null;
    owner.ports.push({ id: native.id, width: num(native.width, 12), height: num(native.height, 12), ...label2 ? { labels: [{ id: native.id + ":port-label", text, width: num(label2.width, 1), height: num(label2.height, 16) }] } : {}, layoutOptions: { "elk.port.side": side, "elk.port.borderOffset": String(-Math.min(num(native.width, 12), num(native.height, 12)) / 2) } });
    anchors.set(native.id, { identityStatus: native.semanticId ? "actual-model-port" : "modeled-pin", semanticId: native.semanticId ?? null, representationId: native.id, ownerId: native.parentId, ...native.nativePortId ? { nativePortId: native.nativePortId, nativePort: structuredClone(native.nativePort) } : {} });
  }
  function anchor(id, edgeId, side) {
    if (actualPorts.has(id)) return id;
    const portId = `syspresent-anchor:${edgeId}:${side}`, owner = elkNodes.get(id);
    if (!owner) throw Error("Native endpoint has no drawing owner: " + id);
    owner.ports.push({ id: portId, width: 0, height: 0, layoutOptions: { "elk.port.side": side === "source" ? "SOUTH" : "NORTH" } });
    anchors.set(portId, { identityStatus: "drawing-anchor", semanticId: null, representationId: null, ownerId: id });
    return portId;
  }
  for (const [i, edge] of [...view.edges].sort((a, b) => a.id.localeCompare(b.id)).entries()) {
    const [source, target, reversed] = orientation(edge, behavioral, view.kind), id = `syspresent-edge:${i}`, label2 = edge.label ? options.measureLabel?.(edge.label) ?? { width: String(edge.label).length * 7.2 + 4, height: 16 } : null;
    const sourcePin = reversed ? edge.targetAttachment : edge.sourceAttachment, targetPin = reversed ? edge.sourceAttachment : edge.targetAttachment;
    graph.edges.push({ id, sources: [anchor(sourcePin ?? source, id, "source")], targets: [anchor(targetPin ?? target, id, "target")], ...label2 ? { labels: [{ id: id + ":label", text: edge.label, width: num(label2.width, 1), height: num(label2.height, 16) }] } : {} });
    edgeMap.set(id, { edge, reversed });
  }
  return { graph, nodes, children, actualPorts, anchors, edgeMap };
}
function readLayout(view, data, laid, options, profile) {
  const positions = /* @__PURE__ */ new Map(), routes = /* @__PURE__ */ new Map(), diagnostics = [], ports = [], nativeRoutes = [];
  function walk(item, ox = 0, oy = 0) {
    const x = ox + (item.x ?? 0), y = oy + (item.y ?? 0);
    if (data.nodes.has(item.id)) {
      const native = data.nodes.get(item.id);
      positions.set(item.id, { ...native, x, y, width: item.width, height: item.height, ...item.children?.length ? { headerHeight: dimensions(native).height } : {} });
    }
    for (const port of item.ports ?? []) {
      const anchor = data.anchors.get(port.id), position = { ...anchor, id: port.id, x: x + port.x + port.width / 2, y: y + port.y + port.height / 2, side: port.layoutOptions?.["elk.port.side"] };
      ports.push(position);
      if (data.actualPorts.has(port.id)) {
        const native = data.nodes.get(port.id), label2 = port.labels?.[0], portLabelBox = label2 ? { x: x + port.x + label2.x, y: y + port.y + label2.y, width: label2.width, height: label2.height } : null;
        positions.set(port.id, { ...native, portSide: port.layoutOptions?.["elk.port.side"], x: x + port.x, y: y + port.y, width: port.width, height: port.height, ...portLabelBox ? { portLabelBox } : {} });
        position.portLabelBox = portLabelBox;
      }
    }
    for (const edge of item.edges ?? []) nativeRoutes.push({ edge, x, y });
    for (const child of item.children ?? []) walk(child, x, y);
  }
  walk(laid);
  for (const record of nativeRoutes) {
    const { edge } = record, native = data.edgeMap.get(edge.id);
    if (!native) continue;
    const container = positions.get(edge.container), x = container?.x ?? record.x, y = container?.y ?? record.y;
    const points = simplify2((edge.sections ?? []).flatMap((s) => [s.startPoint, ...s.bendPoints ?? [], s.endPoint]).map((p) => ({ x: p.x + x, y: p.y + y })));
    const label2 = edge.labels?.[0], labelBox = label2 ? { x: label2.x + x, y: label2.y + y, width: label2.width, height: label2.height } : void 0;
    const first = data.anchors.get(edge.sources?.[0]), last = data.anchors.get(edge.targets?.[0]);
    routes.set(native.edge.id, { ...native.edge, points: native.reversed ? [...points].reverse() : points, ...labelBox ? { labelBox, x: labelBox.x, y: labelBox.y + labelBox.height * 0.78 } : {}, sourceAnchor: native.reversed ? last : first, targetAnchor: native.reversed ? first : last, routingEngine: "elk-layered" });
  }
  const nodes = view.nodes.map((n) => positions.get(n.id)).filter(Boolean), ancestors = (id) => {
    const result = /* @__PURE__ */ new Set();
    let node = data.nodes.get(id);
    while (node?.parentId && data.nodes.has(node.parentId)) {
      if (result.has(node.parentId)) throw Error("Cyclic native drawing containment");
      result.add(node.parentId);
      node = data.nodes.get(node.parentId);
    }
    return result;
  };
  if (nodes.length !== view.nodes.length || nodes.some((n) => ![n.x, n.y, n.width, n.height].every(Number.isFinite))) throw Error("ELK returned invalid tile geometry");
  const edges = view.edges.map((native) => {
    const edge = routes.get(native.id) ?? { ...native, points: [] }, anc = /* @__PURE__ */ new Set([...ancestors(native.sourceAttachment ?? native.source), ...ancestors(native.targetAttachment ?? native.target)]);
    const obstacles = nodes.flatMap((n) => data.children.get(n.id)?.length ? anc.has(n.id) ? [{ ...n, height: n.headerHeight }] : [n] : data.actualPorts.has(n.id) && [native.sourceAttachment ?? native.source, native.targetAttachment ?? native.target].includes(n.id) ? [] : [n]);
    const blocked = edge.points.length < 2 || edge.points.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y)) || edge.points.slice(1).some((point, i) => obstacles.some((n) => segmentHits(edge.points[i], point, n)));
    if (blocked) {
      diagnostics.push({ reason: "unroutable-connection", relationshipId: native.id, message: "No unobstructed native connection route was found." });
      edge.points = [];
      edge.routingBlocked = true;
    }
    if (edge.labelBox && (![edge.labelBox.x, edge.labelBox.y, edge.labelBox.width, edge.labelBox.height].every(Number.isFinite) || obstacles.some((n) => overlap2(edge.labelBox, n, 2)))) {
      delete edge.labelBox;
      edge.labelOmitted = true;
      diagnostics.push({ reason: "unplaceable-connection-label", relationshipId: native.id });
    }
    return edge;
  });
  for (let i = 0; i < edges.length; i++) for (let j = 0; j < i; j++) if (edges[i].labelBox && edges[j].labelBox && overlap2(edges[i].labelBox, edges[j].labelBox, 2)) {
    delete edges[i].labelBox;
    edges[i].labelOmitted = true;
    diagnostics.push({ reason: "unplaceable-connection-label", relationshipId: edges[i].id });
  }
  return { ...view, nodes, edges, ports, diagnostics, omissions: [...view.omissions ?? [], ...diagnostics], bounds: { x: 0, y: 0, width: laid.width, height: laid.height }, layoutEngine: "elk-layered", layoutProfile: profile.capacity ? "responsive-partitions-" + profile.capacity : "layered", panels: structuredClone(options.panels ?? []) };
}
async function layoutDiagram(nativeView, options = {}) {
  const { width = 1e3, height = 700, elk } = options;
  if (!elk?.layout) throw Error("layoutDiagram requires an ELK engine");
  if (!Number.isFinite(width) || width <= 0 || !Number.isFinite(height) || height <= 0) throw Error("Invalid viewport");
  const view = projectEmbeddedPorts(projectView(nativeView)), area = options.panels?.length ? graphArea(width, height, options.panels) : { width, height };
  if (!view.nodes.length) return { ...view, nodes: [], edges: [], ports: [], diagnostics: [], bounds: { x: 0, y: 0, width: 1, height: 1 }, layoutEngine: "elk-layered" };
  const rootCount = view.nodes.filter((n) => !n.parentId).length, behavioral = behavioralKinds.has(view.kind), profiles2 = [{ gap: 32 }];
  if (!behavioral && rootCount > 2 && area.width < 700) for (const capacity of [2, 1]) profiles2.push({ gap: 28, capacity });
  const candidates = [];
  for (const profile of profiles2) {
    try {
      const data = makeGraph(view, options, profile), laid = await elk.layout(data.graph), candidate = readLayout(view, data, laid, options, profile);
      const scale = Math.min(1, area.width / (candidate.bounds.width + 20), area.height / (candidate.bounds.height + 20));
      candidate.layoutFitScale = scale;
      const invalid = candidate.diagnostics.length;
      candidate.layoutScore = invalid * 1e4 + 1 / Math.max(0.01, scale) + candidate.bounds.width * candidate.bounds.height / 1e8;
      candidates.push(candidate);
    } catch (error) {
      candidates.push({ ...view, nodes: [], edges: view.edges.map((e) => ({ ...e, points: [], routingBlocked: true })), ports: [], bounds: { x: 0, y: 0, width: 1, height: 1 }, layoutEngine: "elk-layered", layoutScore: 1e9, diagnostics: [{ reason: "layout-failed", message: error.message }] });
    }
  }
  candidates.sort((a, b) => a.layoutScore - b.layoutScore);
  if (!candidates.some((candidate) => candidate.nodes.length)) throw Error(candidates[0]?.diagnostics[0]?.message ?? "ELK could not lay out the native diagram");
  return candidates[0];
}

// src/canvas-prototype/engine/client.mjs
function createSemanticEngine({ assetBase, assetVersion, workerURL = new URL("./worker.js", import.meta.url), WorkerClass = globalThis.Worker } = {}) {
  if (!assetBase) throw new TypeError("assetBase must locate the pinned Go/WASM engine assets");
  const worker = new WorkerClass(workerURL);
  const pending = /* @__PURE__ */ new Map();
  let sequence = 0;
  let closed = false;
  function request(method, params) {
    if (closed) return Promise.reject(new Error("Semantic engine has been terminated"));
    const id = ++sequence;
    return new Promise((resolve2, reject) => {
      pending.set(id, { resolve: resolve2, reject });
      worker.postMessage({ id, method, params });
    });
  }
  function rejectAll(error) {
    for (const job of pending.values()) job.reject(error);
    pending.clear();
  }
  worker.onmessage = ({ data }) => {
    const job = pending.get(data.id);
    if (!job) return;
    pending.delete(data.id);
    if (data.error) {
      const error = new Error(data.error.message);
      error.code = data.error.code;
      job.reject(error);
    } else job.resolve(data.result);
  };
  worker.onerror = (event) => {
    closed = true;
    rejectAll(new Error(event.message || "Semantic engine worker failed"));
    worker.terminate();
  };
  const base = new URL(assetBase, globalThis.location?.href || import.meta.url).href;
  const ready = request("Initialize", { assetBase: base, assetVersion });
  return {
    ready,
    async call(method, params = {}) {
      await ready;
      return request(method, params);
    },
    terminate() {
      closed = true;
      worker.terminate();
      rejectAll(new Error("Semantic engine has been terminated"));
    }
  };
}

// node_modules/fflate/esm/browser.js
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start2) {
  var b = new u16(31);
  for (var i = 0; i < 31; ++i) {
    b[i] = start2 += 1 << eb[i - 1];
  }
  var r = new i32(b[30]);
  for (var i = 1; i < 30; ++i) {
    for (var j = b[i]; j < b[i + 1]; ++j) {
      r[j] = j - b[i] << 5 | i;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var x;
var i;
var hMap = function(cd, mb, r) {
  var s = cd.length;
  var i = 0;
  var l = new u16(mb);
  for (; i < s; ++i) {
    if (cd[i])
      ++l[cd[i] - 1];
  }
  var le = new u16(mb);
  for (i = 1; i < mb; ++i) {
    le[i] = le[i - 1] + l[i - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i = 0; i < s; ++i) {
      if (cd[i]) {
        var sv = i << 4 | cd[i];
        var r_1 = mb - cd[i];
        var v = le[cd[i] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i = 0; i < s; ++i) {
      if (cd[i]) {
        co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
      }
    }
  }
  return co;
};
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flm = /* @__PURE__ */ hMap(flt, 9, 0);
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdm = /* @__PURE__ */ hMap(fdt, 5, 0);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
  var m = a[0];
  for (var i = 1; i < a.length; ++i) {
    if (a[i] > m)
      m = a[i];
  }
  return m;
};
var bits = function(d, p, m) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var inflt = function(dat, st, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st.f && !st.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st.i != 2;
  var noSt = st.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l2) {
    var bl = buf.length;
    if (l2 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l2));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
        if (t > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + l);
        buf.set(dat.subarray(s, t), bt);
        st.b = bt += l, st.p = pos = t * 8, st.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i = 0; i < hcLen; ++i) {
          clt[clim[i]] = bits(dat, pos + i * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i = 0; i < tl; ) {
          var r = clm[bits(dat, pos, clbmsk)];
          pos += r & 15;
          var s = r >> 4;
          if (s < 16) {
            ldt[i++] = s;
          } else {
            var c = 0, n = 0;
            if (s == 16)
              n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
            else if (s == 17)
              n = 3 + bits(dat, pos, 7), pos += 3;
            else if (s == 18)
              n = 11 + bits(dat, pos, 127), pos += 7;
            while (n--)
              ldt[i++] = c;
          }
        }
        var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
        lbt = max(lt);
        dbt = max(dt);
        lm = hMap(lt, lbt, 1);
        dm = hMap(dt, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
      pos += c & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c)
        err(2);
      if (sym < 256)
        buf[bt++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add = sym - 254;
        if (sym > 264) {
          var i = sym - 257, b = fleb[i];
          add = bits(dat, pos, (1 << b) - 1) + fl[i];
          pos += b;
        }
        var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
        if (!d)
          err(3);
        pos += d & 15;
        var dt = fd[dsym];
        if (dsym > 3) {
          var b = fdeb[dsym];
          dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + 131072);
        var end = bt + add;
        if (bt < dt) {
          var shift = dl - dt, dend = Math.min(dt, end);
          if (shift + bt < 0)
            err(3);
          for (; bt < dend; ++bt)
            buf[bt] = dict[shift + bt];
        }
        for (; bt < end; ++bt)
          buf[bt] = buf[bt - dt];
      }
    }
    st.l = lm, st.p = lpos, st.b = bt, st.f = final;
    if (lm)
      final = 1, st.m = lbt, st.d = dm, st.n = dbt;
  } while (!final);
  return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var wbits = function(d, p, v) {
  v <<= p & 7;
  var o = p / 8 | 0;
  d[o] |= v;
  d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
  v <<= p & 7;
  var o = p / 8 | 0;
  d[o] |= v;
  d[o + 1] |= v >> 8;
  d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
  var t = [];
  for (var i = 0; i < d.length; ++i) {
    if (d[i])
      t.push({ s: i, f: d[i] });
  }
  var s = t.length;
  var t2 = t.slice();
  if (!s)
    return { t: et, l: 0 };
  if (s == 1) {
    var v = new u8(t[0].s + 1);
    v[t[0].s] = 1;
    return { t: v, l: 1 };
  }
  t.sort(function(a, b) {
    return a.f - b.f;
  });
  t.push({ s: -1, f: 25001 });
  var l = t[0], r = t[1], i0 = 0, i1 = 1, i2 = 2;
  t[0] = { s: -1, f: l.f + r.f, l, r };
  while (i1 != s - 1) {
    l = t[t[i0].f < t[i2].f ? i0++ : i2++];
    r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
    t[i1++] = { s: -1, f: l.f + r.f, l, r };
  }
  var maxSym = t2[0].s;
  for (var i = 1; i < s; ++i) {
    if (t2[i].s > maxSym)
      maxSym = t2[i].s;
  }
  var tr = new u16(maxSym + 1);
  var mbt = ln(t[i1 - 1], tr, 0);
  if (mbt > mb) {
    var i = 0, dt = 0;
    var lft = mbt - mb, cst = 1 << lft;
    t2.sort(function(a, b) {
      return tr[b.s] - tr[a.s] || a.f - b.f;
    });
    for (; i < s; ++i) {
      var i2_1 = t2[i].s;
      if (tr[i2_1] > mb) {
        dt += cst - (1 << mbt - tr[i2_1]);
        tr[i2_1] = mb;
      } else
        break;
    }
    dt >>= lft;
    while (dt > 0) {
      var i2_2 = t2[i].s;
      if (tr[i2_2] < mb)
        dt -= 1 << mb - tr[i2_2]++ - 1;
      else
        ++i;
    }
    for (; i >= 0 && dt; --i) {
      var i2_3 = t2[i].s;
      if (tr[i2_3] == mb) {
        --tr[i2_3];
        ++dt;
      }
    }
    mbt = mb;
  }
  return { t: new u8(tr), l: mbt };
};
var ln = function(n, l, d) {
  return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
  var s = c.length;
  while (s && !c[--s])
    ;
  var cl = new u16(++s);
  var cli = 0, cln = c[0], cls = 1;
  var w = function(v) {
    cl[cli++] = v;
  };
  for (var i = 1; i <= s; ++i) {
    if (c[i] == cln && i != s)
      ++cls;
    else {
      if (!cln && cls > 2) {
        for (; cls > 138; cls -= 138)
          w(32754);
        if (cls > 2) {
          w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
          cls = 0;
        }
      } else if (cls > 3) {
        w(cln), --cls;
        for (; cls > 6; cls -= 6)
          w(8304);
        if (cls > 2)
          w(cls - 3 << 5 | 8208), cls = 0;
      }
      while (cls--)
        w(cln);
      cls = 1;
      cln = c[i];
    }
  }
  return { c: cl.subarray(0, cli), n: s };
};
var clen = function(cf, cl) {
  var l = 0;
  for (var i = 0; i < cl.length; ++i)
    l += cf[i] * cl[i];
  return l;
};
var wfblk = function(out, pos, dat) {
  var s = dat.length;
  var o = shft(pos + 2);
  out[o] = s & 255;
  out[o + 1] = s >> 8;
  out[o + 2] = out[o] ^ 255;
  out[o + 3] = out[o + 1] ^ 255;
  for (var i = 0; i < s; ++i)
    out[o + i + 4] = dat[i];
  return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
  wbits(out, p++, final);
  ++lf[256];
  var _a2 = hTree(lf, 15), dlt = _a2.t, mlb = _a2.l;
  var _b2 = hTree(df, 15), ddt = _b2.t, mdb = _b2.l;
  var _c = lc(dlt), lclt = _c.c, nlc = _c.n;
  var _d = lc(ddt), lcdt = _d.c, ndc = _d.n;
  var lcfreq = new u16(19);
  for (var i = 0; i < lclt.length; ++i)
    ++lcfreq[lclt[i] & 31];
  for (var i = 0; i < lcdt.length; ++i)
    ++lcfreq[lcdt[i] & 31];
  var _e = hTree(lcfreq, 7), lct = _e.t, mlcb = _e.l;
  var nlcc = 19;
  for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc)
    ;
  var flen = bl + 5 << 3;
  var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
  var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
  if (bs >= 0 && flen <= ftlen && flen <= dtlen)
    return wfblk(out, p, dat.subarray(bs, bs + bl));
  var lm, ll, dm, dl;
  wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
  if (dtlen < ftlen) {
    lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
    var llm = hMap(lct, mlcb, 0);
    wbits(out, p, nlc - 257);
    wbits(out, p + 5, ndc - 1);
    wbits(out, p + 10, nlcc - 4);
    p += 14;
    for (var i = 0; i < nlcc; ++i)
      wbits(out, p + 3 * i, lct[clim[i]]);
    p += 3 * nlcc;
    var lcts = [lclt, lcdt];
    for (var it = 0; it < 2; ++it) {
      var clct = lcts[it];
      for (var i = 0; i < clct.length; ++i) {
        var len = clct[i] & 31;
        wbits(out, p, llm[len]), p += lct[len];
        if (len > 15)
          wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
      }
    }
  } else {
    lm = flm, ll = flt, dm = fdm, dl = fdt;
  }
  for (var i = 0; i < li; ++i) {
    var sym = syms[i];
    if (sym > 255) {
      var len = sym >> 18 & 31;
      wbits16(out, p, lm[len + 257]), p += ll[len + 257];
      if (len > 7)
        wbits(out, p, sym >> 23 & 31), p += fleb[len];
      var dst = sym & 31;
      wbits16(out, p, dm[dst]), p += dl[dst];
      if (dst > 3)
        wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
    } else {
      wbits16(out, p, lm[sym]), p += ll[sym];
    }
  }
  wbits16(out, p, lm[256]);
  return p + ll[256];
};
var deo = /* @__PURE__ */ new i32([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]);
var et = /* @__PURE__ */ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
  var s = st.z || dat.length;
  var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
  var w = o.subarray(pre, o.length - post);
  var lst = st.l;
  var pos = (st.r || 0) & 7;
  if (lvl) {
    if (pos)
      w[0] = st.r >> 3;
    var opt = deo[lvl - 1];
    var n = opt >> 13, c = opt & 8191;
    var msk_1 = (1 << plvl) - 1;
    var prev = st.p || new u16(32768), head = st.h || new u16(msk_1 + 1);
    var bs1_1 = Math.ceil(plvl / 3), bs2_1 = 2 * bs1_1;
    var hsh = function(i2) {
      return (dat[i2] ^ dat[i2 + 1] << bs1_1 ^ dat[i2 + 2] << bs2_1) & msk_1;
    };
    var syms = new i32(25e3);
    var lf = new u16(288), df = new u16(32);
    var lc_1 = 0, eb = 0, i = st.i || 0, li = 0, wi = st.w || 0, bs = 0;
    for (; i + 2 < s; ++i) {
      var hv = hsh(i);
      var imod = i & 32767, pimod = head[hv];
      prev[imod] = pimod;
      head[hv] = imod;
      if (wi <= i) {
        var rem = s - i;
        if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
          pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
          li = lc_1 = eb = 0, bs = i;
          for (var j = 0; j < 286; ++j)
            lf[j] = 0;
          for (var j = 0; j < 30; ++j)
            df[j] = 0;
        }
        var l = 2, d = 0, ch_1 = c, dif = imod - pimod & 32767;
        if (rem > 2 && hv == hsh(i - dif)) {
          var maxn = Math.min(n, rem) - 1;
          var maxd = Math.min(32767, i);
          var ml = Math.min(258, rem);
          while (dif <= maxd && --ch_1 && imod != pimod) {
            if (dat[i + l] == dat[i + l - dif]) {
              var nl = 0;
              for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl)
                ;
              if (nl > l) {
                l = nl, d = dif;
                if (nl > maxn)
                  break;
                var mmd = Math.min(dif, nl - 2);
                var md = 0;
                for (var j = 0; j < mmd; ++j) {
                  var ti = i - dif + j & 32767;
                  var pti = prev[ti];
                  var cd = ti - pti & 32767;
                  if (cd > md)
                    md = cd, pimod = ti;
                }
              }
            }
            imod = pimod, pimod = prev[imod];
            dif += imod - pimod & 32767;
          }
        }
        if (d) {
          syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
          var lin = revfl[l] & 31, din = revfd[d] & 31;
          eb += fleb[lin] + fdeb[din];
          ++lf[257 + lin];
          ++df[din];
          wi = i + l;
          ++lc_1;
        } else {
          syms[li++] = dat[i];
          ++lf[dat[i]];
        }
      }
    }
    for (i = Math.max(i, wi); i < s; ++i) {
      syms[li++] = dat[i];
      ++lf[dat[i]];
    }
    pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
    if (!lst) {
      st.r = pos & 7 | w[pos / 8 | 0] << 3;
      pos -= 7;
      st.h = head, st.p = prev, st.i = i, st.w = wi;
    }
  } else {
    for (var i = st.w || 0; i < s + lst; i += 65535) {
      var e = i + 65535;
      if (e >= s) {
        w[pos / 8 | 0] = lst;
        e = s;
      }
      pos = wfblk(w, pos + 1, dat.subarray(i, e));
    }
    st.i = s;
  }
  return slc(o, 0, pre + shft(pos) + post);
};
var crct = /* @__PURE__ */ function() {
  var t = new Int32Array(256);
  for (var i = 0; i < 256; ++i) {
    var c = i, k = 9;
    while (--k)
      c = (c & 1 && -306674912) ^ c >>> 1;
    t[i] = c;
  }
  return t;
}();
var crc = function() {
  var c = -1;
  return {
    p: function(d) {
      var cr = c;
      for (var i = 0; i < d.length; ++i)
        cr = crct[cr & 255 ^ d[i]] ^ cr >>> 8;
      c = cr;
    },
    d: function() {
      return ~c;
    }
  };
};
var dopt = function(dat, opt, pre, post, st) {
  if (!st) {
    st = { l: 1 };
    if (opt.dictionary) {
      var dict = opt.dictionary.subarray(-32768);
      var newDat = new u8(dict.length + dat.length);
      newDat.set(dict);
      newDat.set(dat, dict.length);
      dat = newDat;
      st.w = dict.length;
    }
  }
  return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var mrg = function(a, b) {
  var o = {};
  for (var k in a)
    o[k] = a[k];
  for (var k in b)
    o[k] = b[k];
  return o;
};
var b2 = function(d, b) {
  return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
  return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
  return b4(d, b) + b4(d, b + 4) * 4294967296;
};
var wbytes = function(d, b, v) {
  for (; v; ++b)
    d[b] = v, v >>>= 8;
};
function deflateSync(data, opts) {
  return dopt(data, opts || {}, 0, 0);
}
function inflateSync(data, opts) {
  return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var fltn = function(d, p, t, o) {
  for (var k in d) {
    var val = d[k], n = p + k, op = o;
    if (Array.isArray(val))
      op = mrg(o, val[1]), val = val[0];
    if (val instanceof u8)
      t[n] = [val, op];
    else {
      t[n += "/"] = [new u8(0), op];
      fltn(val, n, t, o);
    }
  }
};
var te = typeof TextEncoder != "undefined" && /* @__PURE__ */ new TextEncoder();
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
var dutf8 = function(d) {
  for (var r = "", i = 0; ; ) {
    var c = d[i++];
    var eb = (c > 127) + (c > 223) + (c > 239);
    if (i + eb > d.length)
      return { s: r, r: slc(d, i - 1) };
    if (!eb)
      r += String.fromCharCode(c);
    else if (eb == 3) {
      c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
    } else if (eb & 1)
      r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
    else
      r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
  }
};
function strToU8(str, latin1) {
  if (latin1) {
    var ar_1 = new u8(str.length);
    for (var i = 0; i < str.length; ++i)
      ar_1[i] = str.charCodeAt(i);
    return ar_1;
  }
  if (te)
    return te.encode(str);
  var l = str.length;
  var ar = new u8(str.length + (str.length >> 1));
  var ai = 0;
  var w = function(v) {
    ar[ai++] = v;
  };
  for (var i = 0; i < l; ++i) {
    if (ai + 5 > ar.length) {
      var n = new u8(ai + 8 + (l - i << 1));
      n.set(ar);
      ar = n;
    }
    var c = str.charCodeAt(i);
    if (c < 128 || latin1)
      w(c);
    else if (c < 2048)
      w(192 | c >> 6), w(128 | c & 63);
    else if (c > 55295 && c < 57344)
      c = 65536 + (c & 1023 << 10) | str.charCodeAt(++i) & 1023, w(240 | c >> 18), w(128 | c >> 12 & 63), w(128 | c >> 6 & 63), w(128 | c & 63);
    else
      w(224 | c >> 12), w(128 | c >> 6 & 63), w(128 | c & 63);
  }
  return slc(ar, 0, ai);
}
function strFromU8(dat, latin1) {
  if (latin1) {
    var r = "";
    for (var i = 0; i < dat.length; i += 16384)
      r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
    return r;
  } else if (td) {
    return td.decode(dat);
  } else {
    var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
    if (r.length)
      err(8);
    return s;
  }
}
var slzh = function(d, b) {
  return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
  var fnl = b2(d, b + 28), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl, bs = b4(d, b + 20);
  var _a2 = z && bs == 4294967295 ? z64e(d, es) : [bs, b4(d, b + 24), b4(d, b + 42)], sc = _a2[0], su = _a2[1], off = _a2[2];
  return [b2(d, b + 10), sc, su, fn, es + b2(d, b + 30) + b2(d, b + 32), off];
};
var z64e = function(d, b) {
  for (; b2(d, b) != 1; b += 4 + b2(d, b + 2))
    ;
  return [b8(d, b + 12), b8(d, b + 4), b8(d, b + 20)];
};
var exfl = function(ex) {
  var le = 0;
  if (ex) {
    for (var k in ex) {
      var l = ex[k].length;
      if (l > 65535)
        err(9);
      le += l + 4;
    }
  }
  return le;
};
var wzh = function(d, b, f, fn, u, c, ce, co) {
  var fl2 = fn.length, ex = f.extra, col = co && co.length;
  var exl = exfl(ex);
  wbytes(d, b, ce != null ? 33639248 : 67324752), b += 4;
  if (ce != null)
    d[b++] = 20, d[b++] = f.os;
  d[b] = 20, b += 2;
  d[b++] = f.flag << 1 | (c < 0 && 8), d[b++] = u && 8;
  d[b++] = f.compression & 255, d[b++] = f.compression >> 8;
  var dt = new Date(f.mtime == null ? Date.now() : f.mtime), y = dt.getFullYear() - 1980;
  if (y < 0 || y > 119)
    err(10);
  wbytes(d, b, y << 25 | dt.getMonth() + 1 << 21 | dt.getDate() << 16 | dt.getHours() << 11 | dt.getMinutes() << 5 | dt.getSeconds() >> 1), b += 4;
  if (c != -1) {
    wbytes(d, b, f.crc);
    wbytes(d, b + 4, c < 0 ? -c - 2 : c);
    wbytes(d, b + 8, f.size);
  }
  wbytes(d, b + 12, fl2);
  wbytes(d, b + 14, exl), b += 16;
  if (ce != null) {
    wbytes(d, b, col);
    wbytes(d, b + 6, f.attrs);
    wbytes(d, b + 10, ce), b += 14;
  }
  d.set(fn, b);
  b += fl2;
  if (exl) {
    for (var k in ex) {
      var exf = ex[k], l = exf.length;
      wbytes(d, b, +k);
      wbytes(d, b + 2, l);
      d.set(exf, b + 4), b += 4 + l;
    }
  }
  if (col)
    d.set(co, b), b += col;
  return b;
};
var wzf = function(o, b, c, d, e) {
  wbytes(o, b, 101010256);
  wbytes(o, b + 8, c);
  wbytes(o, b + 10, c);
  wbytes(o, b + 12, d);
  wbytes(o, b + 16, e);
};
function zipSync(data, opts) {
  if (!opts)
    opts = {};
  var r = {};
  var files = [];
  fltn(data, "", r, opts);
  var o = 0;
  var tot = 0;
  for (var fn in r) {
    var _a2 = r[fn], file = _a2[0], p = _a2[1];
    var compression = p.level == 0 ? 0 : 8;
    var f = strToU8(fn), s = f.length;
    var com = p.comment, m = com && strToU8(com), ms = m && m.length;
    var exl = exfl(p.extra);
    if (s > 65535)
      err(11);
    var d = compression ? deflateSync(file, p) : file, l = d.length;
    var c = crc();
    c.p(file);
    files.push(mrg(p, {
      size: file.length,
      crc: c.d(),
      c: d,
      f,
      m,
      u: s != fn.length || m && com.length != ms,
      o,
      compression
    }));
    o += 30 + s + exl + l;
    tot += 76 + 2 * (s + exl) + (ms || 0) + l;
  }
  var out = new u8(tot + 22), oe = o, cdl = tot - o;
  for (var i = 0; i < files.length; ++i) {
    var f = files[i];
    wzh(out, f.o, f, f.f, f.u, f.c.length);
    var badd = 30 + f.f.length + exfl(f.extra);
    out.set(f.c, f.o + badd);
    wzh(out, o, f, f.f, f.u, f.c.length, f.o, f.m), o += 16 + badd + (f.m ? f.m.length : 0);
  }
  wzf(out, o, files.length, cdl, oe);
  return out;
}
function unzipSync(data, opts) {
  var files = {};
  var e = data.length - 22;
  for (; b4(data, e) != 101010256; --e) {
    if (!e || data.length - e > 65558)
      err(13);
  }
  ;
  var c = b2(data, e + 8);
  if (!c)
    return {};
  var o = b4(data, e + 16);
  var z = o == 4294967295 || c == 65535;
  if (z) {
    var ze = b4(data, e - 12);
    z = b4(data, ze) == 101075792;
    if (z) {
      c = b4(data, ze + 32);
      o = b4(data, ze + 48);
    }
  }
  var fltr = opts && opts.filter;
  for (var i = 0; i < c; ++i) {
    var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
    o = no;
    if (!fltr || fltr({
      name: fn,
      size: sc,
      originalSize: su,
      compression: c_2
    })) {
      if (!c_2)
        files[fn] = slc(data, b, b + sc);
      else if (c_2 == 8)
        files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
      else
        err(14, "unknown compression type " + c_2);
    }
  }
  return files;
}

// src/canvas-prototype/project.mjs
var SCHEMA = "syspresent.project.v1";
function projectPath(name) {
  if (typeof name !== "string" || !name || name.startsWith("/") || name.includes("\\") || name.includes(":") || name.split("/").some((x) => x === ".." || x === "." || !x)) throw Error("Invalid project path: " + name);
  return name;
}
var fileText = (project, name) => {
  const value = project.files[projectPath(name)];
  if (value === void 0) throw Error("Missing project file: " + name);
  return typeof value === "string" ? value : strFromU8(value);
};
function validateProject(project) {
  const m = project.manifest;
  if (m?.schemaVersion !== SCHEMA) throw Error("Unsupported project manifest");
  for (const key of ["modelSources", "viewSources", "systemOfInterest"]) if (!Array.isArray(m[key]) || !m[key].length || !m[key].every((x) => typeof x === "string" && x)) throw Error("Project requires " + key);
  if (m.requirementSeeds !== void 0 && (!Array.isArray(m.requirementSeeds) || !m.requirementSeeds.length || !m.requirementSeeds.every((x) => typeof x === "string" && x))) throw Error("Invalid native requirement seeds");
  if (m.modelRoots !== void 0 && (!Array.isArray(m.modelRoots) || !m.modelRoots.length || !m.modelRoots.every((x) => typeof x === "string" && x))) throw Error("Invalid native model roots");
  for (const name of [...m.modelSources, ...m.viewSources, m.story, ...m.assets ?? []]) fileText(project, name);
  if ((/* @__PURE__ */ new Set([...m.modelSources, ...m.viewSources])).size !== m.modelSources.length + m.viewSources.length) throw Error("Model and view source files must be separate");
  if (!["complete", "scoped"].includes(m.publication?.scope)) throw Error("Publication scope must be complete or scoped");
  return project;
}
function parseStory(markdown2) {
  const scenes = [], pattern = /^```syspresent\s*\n([\s\S]*?)\n```[ \t]*$/gm;
  let previous;
  for (const match of markdown2.matchAll(pattern)) {
    if (previous) previous.markdown = markdown2.slice(previous.bodyStart, match.index).trim();
    let config;
    try {
      config = JSON.parse(match[1]);
    } catch {
      throw Error("Invalid scene JSON near character " + match.index);
    }
    if (config.type !== "scene") throw Error("Canvas prototype requires scene blocks");
    for (const key of ["id", "title", "view", "focus"]) if (typeof config[key] !== "string" || !config[key]) throw Error("Scene requires " + key);
    if (scenes.some((s) => s.id === config.id)) throw Error("Duplicate scene " + config.id);
    if (config.journey !== void 0 && (!Array.isArray(config.journey) || !config.journey.every((x) => typeof x === "string" && x))) throw Error("Invalid scene journey");
    if (!["right", "bottom", "left"].includes(config.panel?.placement ?? "right")) throw Error("Unsupported panel placement");
    previous = { ...config, bodyStart: match.index + match[0].length, markdown: "" };
    scenes.push(previous);
  }
  if (previous) previous.markdown = markdown2.slice(previous.bodyStart).trim();
  return scenes.map(({ bodyStart, ...scene2 }) => scene2);
}
function writeStory(title, scenes) {
  return "# " + title + "\n\n" + scenes.map(({ markdown: markdown2, ...config }) => "```syspresent\n" + JSON.stringify({ ...config, type: "scene" }) + "\n```\n\n" + (markdown2 ?? "").trim() + "\n").join("\n");
}
function packProject(project) {
  validateProject(project);
  const files = {};
  for (const [name, data] of Object.entries(project.files)) files[projectPath(name)] = typeof data === "string" ? strToU8(data) : data;
  files["project.json"] = strToU8(JSON.stringify(project.manifest, null, 2) + "\n");
  return zipSync(files, { level: 6 });
}
function unpackProject(bytes) {
  let expanded = 0;
  const files = unzipSync(bytes, { filter: (entry) => {
    projectPath(entry.name.replace(/\/$/, ""));
    if (entry.name.endsWith("/")) return false;
    if (entry.originalSize > 64 * 1024 * 1024 || (expanded += entry.originalSize) > 160 * 1024 * 1024) throw Error("Project archive exceeds prototype size limit");
    return true;
  } });
  if (!files["project.json"]) throw Error("Project archive requires project.json at its root");
  return validateProject({ manifest: JSON.parse(strFromU8(files["project.json"])), files });
}
function documentsFor(project) {
  return [...project.manifest.modelSources, ...project.manifest.viewSources].map((name) => ({ name, content: fileText(project, name), language: name.endsWith(".kerml") ? "kerml" : "sysml" }));
}
function appendScene(project, scene2) {
  const scenes = parseStory(fileText(project, project.manifest.story));
  if (scenes.some((s) => s.id === scene2.id)) throw Error("Scene ID already exists");
  scenes.push(scene2);
  project.files[project.manifest.story] = writeStory(project.manifest.title, scenes);
  return scenes;
}
function captureViewSource({ packageName = "CanvasCaptured", name, qualifiedNames, definition = "GeneralView" }) {
  const quoted = (s) => "'" + s.replaceAll("\\", "\\\\").replaceAll("'", "\\'") + "'";
  if (!["GeneralView", "ActionFlowView", "InterconnectionView", "StateTransitionView", "SequenceView"].includes(definition)) throw Error("Unsupported captured view definition");
  if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(packageName)) throw Error("Invalid captured package name");
  if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) throw Error("Invalid captured view name");
  const refs2 = [...new Set(qualifiedNames)];
  if (!refs2.length) throw Error("Capture requires native-qualified model elements");
  const reference = (q) => q.split("::").map(quoted).join("::");
  return `package ${packageName} {
    private import StandardViewDefinitions::*;
    view ${name} : ${definition} {
${refs2.map((q) => "        expose " + reference(q) + ";").join("\n")}
    }
}
`;
}
function requirementCoverageSource(qualifiedRoots, packageName = "SyspresentRuntimeContext", seeds) {
  const quoted = (s) => "'" + s.replaceAll("\\", "\\\\").replaceAll("'", "\\'") + "'";
  return `package ${packageName} {
 private import StandardViewDefinitions::*;
 view coverage : GeneralView {
${seeds ? "  @OpenSysMLRenderings::RequirementContext { relationshipDepth = 1; }\n" : ""}  filter @SysML::RequirementUsage or @SysML::RequirementDefinition;
${(seeds ?? qualifiedRoots).map((q) => "  expose " + q.split("::").map(quoted).join("::") + (seeds ? ";" : "::**;")).join("\n")}
 }
}
`;
}
async function sourceDigest(documents) {
  const bytes = new TextEncoder().encode(JSON.stringify(documents));
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function verifiedRuntimeCache(project, { trustedHash, engineVersion, engineFingerprint, documents, modelHash }) {
  const filename = project.manifest.runtimeCache;
  if (!filename || !trustedHash) return null;
  const value = project.files[filename], bytes = typeof value === "string" ? new TextEncoder().encode(value) : value;
  if (!bytes) return null;
  const hash = [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (hash !== trustedHash) return null;
  const cache = JSON.parse(fileText(project, filename));
  if (cache.schemaVersion !== "syspresent.native-cache.v1" || cache.engineVersion !== engineVersion || cache.engineFingerprint !== engineFingerprint || cache.modelHash !== modelHash || cache.sourceDigest !== await sourceDigest(documents)) return null;
  return cache;
}

// src/canvas-prototype/app.mjs
var trustedCacheHash = document.querySelector('meta[name="syspresent-runtime-cache"]')?.content;
var buildVersion = document.querySelector('meta[name="syspresent-build"]')?.content || "development";
var $ = (id) => document.getElementById(id);
var el = (name, text, cls) => {
  const e = document.createElement(name);
  if (text !== void 0) e.textContent = text;
  if (cls) e.className = cls;
  return e;
};
var button = (text, fn) => {
  const e = el("button", text);
  e.type = "button";
  e.onclick = () => Promise.resolve(fn()).catch(report);
  return e;
};
var state = { engine: null, project: null, graph: null, views: /* @__PURE__ */ new Map(), scenes: [], sceneIndex: 0, focus: null, selected: null, view: null, displayed: null, exploring: false, expanded: /* @__PURE__ */ new Set(), collapsed: /* @__PURE__ */ new Set(), rects: /* @__PURE__ */ new Map(), reduce: matchMedia("(prefers-reduced-motion: reduce)").matches, revision: 0, loadRevision: 0, animations: [], transitioning: false, provenance: null, history: [] };
var report = (error) => {
  $("status").textContent = error.message || String(error);
  $("editor-error").textContent = error.message || String(error);
  console.error(error);
};
var element = (id) => state.graph?.elements.find((e) => e.id === id);
var label = (id) => element(id)?.name || id;
var resolve = (value) => state.graph?.elements.find((e) => e.id === value || e.qualifiedName === value)?.id;
var qname = (id) => element(id)?.qualifiedName;
var scene = () => state.scenes[state.sceneIndex];
function scopeIds() {
  const roots = state.project.manifest.systemOfInterest;
  return state.graph.elements.filter((e) => roots.some((root) => e.qualifiedName === root || e.qualifiedName?.startsWith(root + "::"))).map((e) => e.id);
}
function status(text) {
  $("status").textContent = text;
  $("loading-phase").textContent = text;
}
function inline(parent, text) {
  let start2 = 0;
  for (const m of text.matchAll(/\*\*([^*]+)\*\*|`([^`]+)`|\*([^*]+)\*/g)) {
    parent.append(document.createTextNode(text.slice(start2, m.index)));
    parent.append(el(m[1] ? "strong" : m[2] ? "code" : "em", m[1] ?? m[2] ?? m[3]));
    start2 = m.index + m[0].length;
  }
  parent.append(document.createTextNode(text.slice(start2)));
}
function markdown(text) {
  const host = el("div");
  let paragraph = [], list;
  const flush = () => {
    if (paragraph.length) {
      const p = el("p");
      inline(p, paragraph.join(" "));
      host.append(p);
      paragraph = [];
    }
    list = null;
  };
  for (const line of text.split("\n")) {
    const heading = /^(#{1,6})\s+(.+)$/.exec(line), item = /^[-*]\s+(.+)$/.exec(line);
    if (heading) {
      flush();
      host.append(el("h" + Math.min(6, Number(heading[1].length) + 1), heading[2]));
    } else if (item) {
      if (paragraph.length) flush();
      if (!list) {
        list = el("ul");
        host.append(list);
      }
      const li = el("li");
      inline(li, item[1]);
      list.append(li);
    } else if (!line.trim()) flush();
    else paragraph.push(line);
  }
  flush();
  return host;
}
async function exampleProject() {
  const response = await fetch("./project.zip?v=" + buildVersion);
  if (!response.ok) throw Error("Example project unavailable");
  return unpackProject(new Uint8Array(await response.arrayBuffer()));
}
async function compile(project) {
  const documents = documentsFor(project), scenes = parseStory(fileText(project, project.manifest.story));
  let parsed, exported, roots = project.manifest.modelRoots, runtimePackage = "SyspresentRuntimeContext";
  const check = (result) => {
    const errors = (result.diagnostics ?? []).filter((d) => String(d.severity).toLowerCase().includes("error"));
    if (errors.length) throw Error(errors.map((d) => `${d.message} (${d.span?.file ?? "source"}:${d.span?.startLine ?? "?"})`).join("\n"));
    if (!result.modelHash) throw Error("Native engine returned no model identity");
  };
  if (!roots?.length) {
    parsed = await state.engine.call("ParseSources", { documents });
    check(parsed);
    exported = await state.engine.call("ExportModel", { modelHash: parsed.modelHash, projection: "declarations" });
    const rootIDs = (parsed.roots ?? []).flatMap((r) => r.childIds ?? []);
    roots = exported.elements.filter((e) => rootIDs.includes(e["@id"]) && e.qualifiedName).map((e) => e.qualifiedName);
  }
  while (roots.includes(runtimePackage)) runtimePackage += "X";
  status("Resolving the complete project with OpenSysML WASM\u2026");
  const allDocuments = [...documents, { name: "__syspresent_runtime_context.sysml", content: requirementCoverageSource(roots, runtimePackage, project.manifest.requirementSeeds) }];
  parsed = await state.engine.call("ParseSources", { documents: allDocuments });
  check(parsed);
  const cache = await verifiedRuntimeCache(project, { trustedHash: trustedCacheHash, engineVersion: state.engineInfo?.version, engineFingerprint: state.provenance?.assets?.["sysml-wasm.wasm"]?.sha256, documents: allDocuments, modelHash: parsed.modelHash });
  status("Loading model declarations and requirement relationships\u2026");
  exported = cache?.exported ?? await state.engine.call("ExportModel", { modelHash: parsed.modelHash, projection: "declarations" });
  if (!Array.isArray(exported.elements)) throw Error("Native model export has no element array");
  if (project.manifest.modelRoots?.length) {
    const modelRootIDs = parsed.roots.slice(0, project.manifest.modelSources.length).flatMap((r) => r.childIds ?? []), actual = exported.elements.filter((e) => modelRootIDs.includes(e["@id"]) && e.qualifiedName).map((e) => e.qualifiedName);
    const missing = actual.filter((name) => !roots.includes(name));
    if (missing.length) throw Error("Native model roots need rebuilding: " + missing.join(", "));
  }
  const coverage = requireNativeIdentity(adaptNativeView(cache?.coverage ?? await state.engine.call("RenderView", { modelHash: parsed.modelHash, view: runtimePackage + "::coverage", includeSemanticIdentity: true }), runtimePackage + "::coverage"));
  exported.elements = exported.elements.filter((e) => e.qualifiedName !== runtimePackage && !e.qualifiedName?.startsWith(runtimePackage + "::"));
  const availableViews = exported.elements.filter((e) => e["@type"] === "ViewUsage" && e.qualifiedName && e["sysx:sourceLine"]).map((e) => e.qualifiedName);
  const needed = /* @__PURE__ */ new Set([...scenes.map((s) => s.view), ...project.manifest.entryView ? [project.manifest.entryView] : []]), views = /* @__PURE__ */ new Map();
  for (const name of needed) {
    if (!availableViews.includes(name)) throw Error("Native view does not resolve: " + name);
    status("Preparing " + (scenes.find((s) => s.view === name)?.title || "model view") + "\u2026");
    const raw = cache?.views?.[name] ?? await state.engine.call("RenderView", { modelHash: parsed.modelHash, view: name, includeSemanticIdentity: true });
    views.set(name, requireNativeIdentity(adaptNativeView(raw, name)));
  }
  const graph = modelGraph(exported.elements, [...views.values(), coverage]);
  for (const root of project.manifest.systemOfInterest) if (!graph.elements.some((e) => e.qualifiedName === root)) throw Error("System of interest does not resolve: " + root);
  const byName = (value) => graph.elements.find((e) => e.id === value || e.qualifiedName === value)?.id;
  for (const [sceneIndex, item] of scenes.entries()) {
    if (item.journey?.length && (byName(item.journey.at(-1)) !== byName(item.focus) || sceneIndex > 0 && byName(item.journey[0]) !== byName(scenes[sceneIndex - 1].focus))) throw Error(`Scene ${item.id}: saved journey must connect the previous scene focus to this focus`);
    if (!views.has(item.view)) throw Error(`Scene ${item.id}: native view ${item.view} does not resolve`);
    if (!byName(item.focus)) throw Error(`Scene ${item.id}: focus ${item.focus} does not resolve`);
    for (let i = 1; i < (item.journey ?? []).length; i++) {
      const from = byName(item.journey[i - 1]), to = byName(item.journey[i]);
      if (!from || !to || !findEngineeringRoute(graph, { from, to, maxHops: 1 }).found) throw Error(`Scene ${item.id}: saved journey has a missing engineering connection`);
    }
  }
  const scoped = graph.elements.filter((e) => project.manifest.systemOfInterest.some((root) => e.qualifiedName === root || e.qualifiedName?.startsWith(root + "::"))).map((e) => e.id);
  for (let i = 1; i < scenes.length; i++) {
    const a = scenes[i - 1], b = scenes[i], plan = planTransition({ view: views.get(a.view), focus: byName(a.focus) }, { view: views.get(b.view), focus: byName(b.focus) }, { graph, scopeIds: scoped });
    if (plan.mode === "cross-kind" && !plan.route.found) throw Error(`Scene ${b.id}: no engineering route from the previous scene within the presentation boundary`);
  }
  return { project, modelHash: parsed.modelHash, exported, graph, views, scenes, coverage, availableViews };
}
function busy(value) {
  $("loading").hidden = !value;
  for (const id of ["previous", "next", "scenes", "standalone", "return", "fit", "find-toggle", "edit"]) $(id).disabled = value;
}
async function loadProject(project) {
  const revision = ++state.loadRevision;
  ++state.revision;
  busy(true);
  status("Parsing project with OpenSysML WASM\u2026");
  $("selection").hidden = true;
  let compiled;
  try {
    compiled = await compile(validateProject(project));
  } catch (error) {
    if (revision === state.loadRevision) {
      busy(false);
      $("previous").disabled = state.sceneIndex === 0;
      $("next").disabled = state.sceneIndex === state.scenes.length - 1;
    }
    throw error;
  }
  if (revision !== state.loadRevision) return;
  Object.assign(state, compiled, { sceneIndex: 0, selected: null, exploring: false, expanded: /* @__PURE__ */ new Set(), collapsed: /* @__PURE__ */ new Set(), rects: /* @__PURE__ */ new Map(), view: null, displayed: null, history: [], extraViews: /* @__PURE__ */ new Map() });
  busy(false);
  updateLists();
  $("editor-error").textContent = "";
  $("project-menu").open = false;
  if (state.scenes.length) await showScene(0, false);
  else {
    state.focus = resolve(project.manifest.systemOfInterest[0]);
    await explore(state.focus);
  }
  status(`OpenSysML WASM \xB7 ${state.graph.elements.length} native elements \xB7 ${state.availableViews.length} views`);
  $("boundary").textContent = project.manifest.publication.scope === "scoped" ? "Scoped publication \xB7 traversal stays within supplied model" : "Complete project \xB7 standalone exploration available";
}
function updateLists() {
  $("scenes").replaceChildren();
  for (const [i, s] of state.scenes.entries()) {
    const option = el("option", `${i + 1}. ${s.title}`);
    option.value = i;
    $("scenes").append(option);
  }
  $("views").replaceChildren();
  for (const name of state.availableViews) {
    const option = el("option", name);
    option.value = name;
    $("views").append(option);
  }
  $("view-file").replaceChildren();
  for (const name of state.project.manifest.viewSources) {
    const option = el("option", name);
    option.value = name;
    $("view-file").append(option);
  }
}
function panelGeometry(view = state.view) {
  const panel = $("narrative"), stage = $("stage");
  if (state.exploring || !scene()) {
    panel.hidden = true;
    return [];
  }
  panel.hidden = false;
  panel.replaceChildren(el("div", `Scene ${state.sceneIndex + 1} of ${state.scenes.length}`, "scene-count"), el("h2", scene().title), markdown(scene().markdown));
  const width = stage.clientWidth, height = stage.clientHeight, narrow = width < 700, placement = narrow ? "bottom" : scene().panel?.placement ?? "right";
  panel.style.cssText = "";
  panel.style.width = (narrow ? width - 24 : Math.min(390, Math.max(280, width * 0.3))) + "px";
  if (placement === "bottom") {
    panel.style.width = width - 24 + "px";
    panel.style.left = "12px";
    panel.style.bottom = "58px";
    panel.style.maxHeight = (narrow ? Math.max(140, Math.min(height * (height < 560 && (view?.nodes.length ?? 0) > 3 ? 0.3 : 0.42), height - 260)) : Math.max(140, height * 0.25)) + "px";
  } else {
    panel.style.top = "16px";
    panel.style[placement === "left" ? "left" : "right"] = "16px";
    panel.style.maxHeight = Math.max(140, height - 90) + "px";
  }
  const a = panel.getBoundingClientRect(), b = stage.getBoundingClientRect();
  return [{ id: "narrative", x: a.x - b.x, y: a.y - b.y, width: a.width, height: a.height }];
}
function sizeView(view, focus, { compact = false } = {}) {
  return { ...view, nodes: view.nodes.map((n) => {
    const expanded = state.expanded.has(n.semanticId), requirement = !compact && n.kind === "requirement" && n.semanticId === focus && !state.collapsed.has(n.semanticId), documentation = documentationFor(state.graph, n.semanticId);
    const detail = expanded || requirement ? documentation.text || n.detail || (expanded ? "No statement or documentation recorded." : "") : "";
    const attribution = detail && documentation.text && documentation.source?.id !== n.semanticId ? `Statement from ${documentation.source.qualifiedName || documentation.source.name}
` : "";
    const displayDetail = attribution + detail;
    const displayID = element(n.semanticId)?.native?.declaredShortName || documentation.source?.native?.declaredShortName || "";
    const measured = ["initial", "final", "fork", "join", "decision", "merge", "port"].includes(n.kind) ? {} : measureCard(document, { ...n, displayID }, displayDetail);
    return { ...n, ...measured, displayDetail, displayID: element(n.semanticId)?.native?.declaredShortName || documentation.source?.native?.declaredShortName || "" };
  }) };
}
function cancelAnimations() {
  state.motion?.cancel();
  state.motion = null;
  for (const a of state.animations) a.cancel();
  state.animations = [];
}
function svgel(name, attrs = {}) {
  const e = document.createElementNS("http://www.w3.org/2000/svg", name);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
}
var nodeKey = (node, counts, view) => {
  const base = node.kind === "context-boundary" ? "boundary:" + node.semanticId : node.semanticId ? "semantic:" + node.semanticId : "notation:" + view.id + ":" + node.id;
  const count = counts.get(base) ?? 0;
  counts.set(base, count + 1);
  return base + ":" + count;
};
function labelSize(text) {
  const span = el("span", text);
  span.style.cssText = "position:fixed;visibility:hidden;left:-10000px;white-space:pre;font:12px system-ui,sans-serif";
  document.body.append(span);
  const rect = span.getBoundingClientRect();
  span.remove();
  return { width: Math.ceil(rect.width) + 4, height: 16 };
}
async function prepareFrame(view, focus, panels) {
  const stage = $("stage"), area = graphArea(stage.clientWidth, stage.clientHeight, panels);
  const layoutFor = (compact) => layoutDiagram(sizeView(view, focus, { compact }), { width: area.width, height: area.height, elk: state.layoutEngine, measureLabel: labelSize });
  let layout = await layoutFor(false), fitted = fitDiagram(layout, area);
  if (fitted.scale < 0.9 && view.nodes.length > 3 && !state.expanded.has(focus)) {
    layout = await layoutFor(true);
    fitted = fitDiagram(layout, area);
  }
  const active = fitted.nodes.map((n) => ({ ...n, scale: fitted.scale, opacity: 1, context: false }));
  const routed = fitted.edges;
  const labelObstacles = [...routed.filter((e) => e.labelBox).map((e, i) => ({ ...e.labelBox, id: "label-obstacle:" + i })), ...active.flatMap((n) => n.portLabelBox ? [{ ...n.portLabelBox, id: "port-label:" + n.id }] : [])];
  const routeObstacles = routed.flatMap((e) => e.points.slice(1).map((p, i) => ({ id: "route:" + e.id + ":" + i, x: Math.min(p.x, e.points[i].x) - 3, y: Math.min(p.y, e.points[i].y) - 3, width: Math.max(6, Math.abs(p.x - e.points[i].x) + 6), height: Math.max(6, Math.abs(p.y - e.points[i].y) + 6) })));
  const context = surroundingContext(state.graph, layout, { budget: stage.clientWidth < 700 ? 4 : 6 });
  const fringe = positionSurrounding(context, [...active, ...labelObstacles, ...routeObstacles], area, { width: 104, height: 56, gap: 10 });
  const ghosts = fringe.nodes.map((n) => ({ ...n, scale: 1, opacity: 0.22, context: true, displayDetail: "", displayID: "" }));
  const markers = fringe.boundaryMarkers.map((n) => ({ ...n, x: n.x + (n.x === area.x ? -8 : n.x === area.x + area.width ? 8 : 0), y: n.y + (n.y === area.y ? -8 : n.y === area.y + area.height ? 8 : 0), scale: 1, opacity: 0.22, context: true, interactive: false }));
  const nodes = [...active, ...ghosts, ...markers], counts = /* @__PURE__ */ new Map(), byID = /* @__PURE__ */ new Map();
  for (const n of nodes) {
    n.key = nodeKey(n, counts, view);
    n.container = active.some((c) => c.parentId === n.id);
    byID.set(n.id, n);
  }
  const peripheral = routeEdges(fringe.edges.map((e) => ({ ...e, label: "" })), [...nodes, ...labelObstacles], { area });
  const edgeCounts = /* @__PURE__ */ new Map(), edges = [...routed, ...peripheral].map((e) => {
    const a = byID.get(e.sourceAttachment ?? e.source), b = byID.get(e.targetAttachment ?? e.target), ownerA = byID.get(e.source), ownerB = byID.get(e.target), base = [a?.semanticId || a?.key, b?.semanticId || b?.key, e.kind, e.label || ""].join("|"), ordinal = edgeCounts.get(base) ?? 0;
    edgeCounts.set(base, ordinal + 1);
    return { ...e, key: base + ":" + ordinal, sourceKey: a?.key, targetKey: b?.key, sourceSemantic: a?.semanticId || ownerA?.semanticId, targetSemantic: b?.semanticId || ownerB?.semanticId, opacity: e.context ? 0.18 : 1, routePoints: e.points, points: samplePolyline(e.points.length ? e.points : [{ x: 0, y: 0 }, { x: 0, y: 0 }]) };
  });
  const notationNotices = layout.edges.map((e) => ({ e, appearance: edgeAppearance(e, { viewKind: view.kind }) })).filter((p) => !p.appearance.supported).map((p) => ({ reason: "unsupported-notation", target: p.e.target, relationshipId: p.e.id, message: p.appearance.notice }));
  const omissions = [...layout.omissions ?? view.omissions ?? [], ...notationNotices, ...fringe.omissions, ...routed.filter((e) => e.labelOmitted || e.routingBlocked).map((e) => ({ reason: e.labelOmitted ? "label-space" : "route-space", target: e.semanticTarget || e.target, relationshipId: e.semanticId || e.id }))];
  return { view, nodes, edges, area, width: stage.clientWidth, height: stage.clientHeight, scale: fitted.scale, layout, omissions };
}
function face(n) {
  const host = el("span", void 0, "node-face");
  if (n.kind === "port") {
    const text = n.label ?? n.name ?? "";
    if (text) host.append(el("span", text, "port-name"));
    return host;
  }
  const short = (n.name?.split("::").at(-1) || n.kind).replace(/([a-z0-9])([A-Z])/g, "$1\u200B$2");
  host.append(el("span", `\xAB${n.kind}\xBB${n.displayID ? " " + n.displayID : ""}${n.type ? " : " + n.type : ""}`, "kind"), el("span", short, "name"));
  if (n.displayDetail && !n.container) host.append(el("span", n.displayDetail, "detail"));
  return host;
}
function visualNode(n) {
  if (n.kind === "context-boundary") {
    const marker = el("span", void 0, "node context-boundary");
    marker.title = "Additional model context: " + (n.name || n.semanticId);
    marker.setAttribute("role", "img");
    marker.setAttribute("aria-label", marker.title);
    marker.dataset.context = "true";
    marker.textContent = "\xBB";
    return marker;
  }
  const node = el("button", void 0, `node ${n.kind}${n.container ? " container" : ""}${n.context ? " peripheral" : ""}${n.semanticId && n.semanticId === state.selected ? " selected" : ""}`);
  node.type = "button";
  node.dataset.representation = n.id;
  if (n.semanticId) node.dataset.semanticId = n.semanticId;
  node.dataset.context = String(!!n.context);
  node.setAttribute("aria-label", `${n.name || n.kind}: select ${n.kind}${n.context ? " (surrounding context)" : ""}`);
  node.style.zIndex = String(n.context ? 0 : n.container ? 1 : 3);
  node.append(face(n));
  node.onclick = (event) => {
    event.stopPropagation();
    select(n.semanticId, n);
  };
  node.oncontextmenu = (event) => {
    event.preventDefault();
    select(n.semanticId, n);
  };
  return node;
}
var rectValues = (n) => ({ x: n.x, y: n.y, width: n.width, height: n.height, scale: n.scale ?? 1, opacity: n.opacity ?? 1 });
function presenceTrack(frames, key, collection) {
  return frames.map((f, index) => {
    const item = f[collection].find((n) => n.key === key);
    if (item) return item;
    let nearest;
    for (let distance = 1; distance < frames.length && !nearest; distance++) nearest = frames[index - distance]?.[collection].find((n) => n.key === key) ?? frames[index + distance]?.[collection].find((n) => n.key === key);
    return { ...nearest, opacity: 0 };
  });
}
async function paintFrames(frames, { duration = 0, caption = "", outgoingPanel } = {}) {
  clearTrace();
  cancelAnimations();
  const destination = frames.at(-1), svg = $("connections"), host = $("nodes"), stage = $("stage");
  svg.replaceChildren();
  host.replaceChildren();
  svg.setAttribute("viewBox", `0 0 ${stage.clientWidth} ${stage.clientHeight}`);
  const defs = svgel("defs");
  for (const name of ["open-arrow", "filled-arrow", "hollow-triangle", "diamond", "hollow-diamond", "containment"]) {
    const { path, fill, ...attrs } = markerDefinition(name), marker = svgel("marker", { id: "edge-" + name, ...attrs, markerUnits: "userSpaceOnUse" });
    marker.append(svgel("path", { d: path, fill: fill === "line" ? "#426869" : fill === "background" ? "#f5f7f7" : "none", stroke: "#426869", "stroke-width": 1.2 }));
    defs.append(marker);
  }
  svg.append(defs);
  const offsets = frames.length === 5 ? [0, 0.18, 0.5, 0.74, 1] : frames.map((_, i) => i / (frames.length - 1 || 1));
  const nodeKeys = visibleTrackKeys(frames, "nodes"), edgeKeys = visibleTrackKeys(frames, "edges").sort((a, b) => {
    const edge = (key) => destination.edges.find((e) => e.key === key) ?? frames.flatMap((f) => f.edges).find((e) => e.key === key);
    return Number(!!edge(b)?.context) - Number(!!edge(a)?.context);
  });
  const nodeTracks = nodeKeys.map((key) => {
    const track = presenceTrack(frames, key, "nodes"), latest = destination.nodes.find((n) => n.key === key) ?? track.filter((n) => n.opacity > 0).at(-1), node = visualNode(latest);
    host.append(node);
    const first = track.find((n) => n.opacity > 0), oldFace = latest.kind !== "context-boundary" && first && JSON.stringify([first.kind, first.displayDetail, first.type, first.container]) !== JSON.stringify([latest.kind, latest.displayDetail, latest.type, latest.container]) ? face(first) : null;
    if (oldFace) {
      oldFace.classList.add("old-face");
      oldFace.setAttribute("aria-hidden", "true");
      node.append(oldFace);
    }
    return { key, node, latest, oldFace, newFace: node.firstChild, track: track.map(rectValues) };
  });
  const edgeTracks = edgeKeys.map((key) => {
    const track = presenceTrack(frames, key, "edges"), latest = destination.edges.find((e) => e.key === key) ?? track.filter((e) => e.opacity > 0).at(-1), appearance = edgeAppearance(latest, { viewKind: destination.view.kind });
    const group = svgel("g", { "data-relationship": latest.semanticId || latest.id, "data-context": String(!!latest.context), "data-source": latest.sourceSemantic || "", "data-target": latest.targetSemantic || "", role: "button", tabindex: 0, "aria-label": `${latest.label || latest.kind}: ${label(latest.sourceSemantic)} to ${label(latest.targetSemantic)}`, "data-kind": latest.kind });
    const line = svgel("path", { class: "edge-line", fill: "none", stroke: "#426869", "stroke-width": latest.context ? 1.1 : 1.5 });
    for (const [side, marker] of [["start", appearance.sourceMarker], ["end", appearance.targetMarker]]) if (marker !== "none") line.setAttribute("marker-" + side, "url(#edge-" + marker + ")");
    if (appearance.line === "dashed") line.setAttribute("stroke-dasharray", "5 3");
    const oldLine = line.cloneNode();
    oldLine.classList.add("edge-outgoing");
    oldLine.style.opacity = 0;
    const hit = svgel("path", { class: "edge-hit", fill: "none", stroke: "transparent", "stroke-width": latest.context ? 8 : 18, "pointer-events": "stroke" });
    group.append(hit, oldLine, line);
    const title = svgel("title");
    title.textContent = latest.label || latest.kind;
    group.append(title);
    let text;
    if (latest.label && !latest.labelOmitted) {
      text = svgel("text", { "font-size": 12 * (latest.labelScale ?? 1), "font-family": "system-ui, sans-serif", fill: "#355e60", "paint-order": "stroke", stroke: "#f5f7f7", "stroke-width": 4, "text-anchor": "start" });
      text.textContent = latest.label;
      group.append(text);
    }
    group.onclick = (event) => {
      event.stopPropagation();
      traceEdge(latest, key);
    };
    group.onkeydown = (event) => {
      if (["Enter", " "].includes(event.key)) {
        event.preventDefault();
        traceEdge(latest, key);
      }
    };
    svg.append(group);
    const numeric = track.map((e) => {
      const r = { opacity: e.opacity ?? 1, x: e.x ?? 0, y: e.y ?? 0, labelOpacity: e.label && !e.labelOmitted ? 1 : 0 };
      for (const [i, p] of e.points.entries()) {
        r["x" + i] = p.x;
        r["y" + i] = p.y;
      }
      return r;
    });
    return { key, group, line, oldLine, hit, text, latest, track: numeric };
  });
  const draw = (progress, clock) => {
    const nodes = [], edges = [];
    for (const item of nodeTracks) {
      const r = sampleTrack(item.track, offsets, progress), n = item.node;
      n.style.width = r.width / (r.scale || 1) + "px";
      n.style.height = r.height / (r.scale || 1) + "px";
      n.style.transform = `translate(${r.x}px,${r.y}px) scale(${r.scale})`;
      n.style.opacity = r.opacity;
      n.style.pointerEvents = item.latest.interactive !== false && r.opacity > 0.12 ? "auto" : "none";
      n.setAttribute("aria-hidden", String(r.opacity < 0.05));
      if (item.latest.portLabelBox) {
        const label2 = n.querySelector(".port-name"), box = item.latest.portLabelBox;
        if (label2) {
          label2.style.left = (box.x - item.latest.x) / (item.latest.scale || 1) + "px";
          label2.style.top = (box.y - item.latest.y) / (item.latest.scale || 1) + "px";
          label2.style.width = box.width / (item.latest.scale || 1) + "px";
          label2.style.height = box.height / (item.latest.scale || 1) + "px";
        }
      }
      if (item.oldFace) {
        const fade = Math.max(0, Math.min(1, (progress - 0.25) / 0.5));
        item.oldFace.style.opacity = 1 - fade;
        item.newFace.style.opacity = fade;
      }
      nodes.push({ ...item.latest, ...r });
    }
    for (const item of edgeTracks) {
      const r = sampleTrack(item.track, offsets, progress), interpolated = Array.from({ length: 20 }, (_, i) => ({ x: r["x" + i], y: r["y" + i] }));
      const currentNodes = nodes.map((n) => ({ ...n, id: n.key, parentId: n.parentId ? nodes.find((p) => p.id === n.parentId)?.key : void 0 }));
      const edge = { ...item.latest, source: item.latest.sourceKey, target: item.latest.targetKey };
      let points = clock === 1 ? item.latest.routePoints ?? [] : interpolated;
      if (clock !== 1 && !routeIsClear(points, edge, currentNodes, { orthogonalOnly: true })) {
        points = routeEdges([{ ...edge, label: "" }], currentNodes)[0]?.points ?? [];
      }
      if (!routeIsClear(points, edge, currentNodes)) points = [];
      const pathOf = (path2) => path2.map((p, i) => (i ? "L" : "M") + p.x + "," + p.y).join(" "), signature = points.slice(1).map((p, i) => Math.abs(p.x - points[i].x) < 0.01 ? "V" : "H").filter((v, i, a) => !i || v !== a[i - 1]).join("");
      if (clock !== 1 && item.signature && signature !== item.signature) {
        item.outgoingPoints = item.drawnPoints;
        item.routeChangedAt = clock;
      }
      const routeFade = clock === 1 ? 1 : Math.min(1, Math.max(0, (clock - (item.routeChangedAt ?? -1)) * duration / 140));
      let outgoing = item.outgoingPoints?.map((p) => ({ ...p }));
      if (outgoing?.length > 1 && points.length > 1) {
        const first = outgoing[0], second = outgoing[1], last = outgoing.at(-1), penultimate = outgoing.at(-2), horizontalFirst = Math.abs(first.y - second.y) < 0.01, horizontalLast = Math.abs(last.y - penultimate.y) < 0.01;
        outgoing[0] = { ...points[0] };
        outgoing[outgoing.length - 1] = { ...points.at(-1) };
        if (horizontalFirst) second.y = points[0].y;
        else second.x = points[0].x;
        if (horizontalLast) penultimate.y = points.at(-1).y;
        else penultimate.x = points.at(-1).x;
      }
      const oldClear = outgoing && routeIsClear(outgoing, edge, currentNodes, { orthogonalOnly: true });
      item.oldLine.setAttribute("d", oldClear ? pathOf(outgoing) : "");
      item.oldLine.style.opacity = oldClear ? 1 - routeFade : 0;
      const path = pathOf(points);
      item.line.setAttribute("d", path);
      item.line.style.opacity = routeFade;
      item.hit.setAttribute("d", path);
      item.signature = signature;
      item.drawnPoints = points;
      const traveling = duration && clock > 0 && clock < 1, emphasis = traveling ? 0.2 + 0.8 * Math.abs(Math.cos(Math.PI * clock)) : 1;
      item.group.style.opacity = points.length ? r.opacity * emphasis : 0;
      item.group.style.pointerEvents = points.length && r.opacity > 0.1 ? "auto" : "none";
      item.group.setAttribute("aria-hidden", String(!points.length || r.opacity < 0.05));
      item.group.setAttribute("tabindex", points.length && r.opacity > 0.1 ? "0" : "-1");
      if (item.text) {
        item.text.setAttribute("x", r.x);
        item.text.setAttribute("y", r.y);
        item.text.style.opacity = traveling ? Math.max(0, (clock - 0.85) / 0.15) : r.labelOpacity;
      }
      edges.push({ ...item.latest, points, opacity: r.opacity, x: r.x, y: r.y });
    }
    if (outgoingPanel) outgoingPanel.style.opacity = Math.max(0, 1 - clock * 3);
    $("narrative").style.opacity = duration ? Math.min(1, clock * 2) : 1;
    stage.dataset.motionProgress = String(clock);
    state.visualSnapshot = { ...destination, nodes, edges };
  };
  const omissions = destination.omissions;
  $("transition").dataset.notice = String(!!caption);
  $("context-details").hidden = !omissions.length;
  $("context-details").textContent = `Context (${omissions.length})`;
  $("transition").textContent = caption || `${destination.view.kind} \xB7 ${destination.view.nodes.length} active elements`;
  const motion = startTimeline({ duration: state.reduce ? 0 : duration, update: draw });
  state.motion = motion;
  const result = await motion.finished;
  if (!result.cancelled) {
    state.visualSnapshot = destination;
    for (const item of nodeTracks) {
      if (!destination.nodes.some((n) => n.key === item.key)) item.node.remove();
      else {
        item.oldFace?.remove();
        if (item.newFace?.style) item.newFace.style.opacity = 1;
      }
    }
    for (const item of edgeTracks) if (!destination.edges.some((e) => e.key === item.key)) item.group.remove();
    state.layout = { ...destination.layout, displayNodes: destination.nodes.filter((n) => !n.context), scale: destination.scale, area: destination.area };
    state.displayed = destination.view;
    state.displayOmissions = omissions;
    delete stage.dataset.motionProgress;
  }
  outgoingPanel?.remove();
  if (state.motion === motion) state.motion = null;
  return result;
}
async function frame(view, caption = "", duration = 0, focus = state.focus) {
  if (state.transitioning && state.pendingDestination) {
    const pending = state.pendingDestination;
    return transitionTo(pending.view, pending.focus, { animate: false, allowDisconnected: true, journey: pending.journey });
  }
  const revision = ++state.revision, panels = panelGeometry(view), destination = await prepareFrame(view, focus, panels), previous = state.visualSnapshot;
  if (revision !== state.revision) return;
  return paintFrames(duration && previous ? [previous, destination] : [destination], { duration, caption });
}
function gather(ids) {
  const set = new Set(ids), elements = state.graph.elements.filter((e) => set.has(e.id));
  return graphView(state.graph, { elements, relationships: state.graph.relationships.filter((e) => set.has(e.source) && set.has(e.target)) }, "General View journey");
}
async function transitionTo(view, focus, { animate = true, journey, allowDisconnected = false } = {}) {
  const revision = ++state.revision, previous = state.view;
  const plan = previous ? planTransition({ view: previous, focus: state.previousFocus }, { view, focus }, { graph: state.graph, scopeIds: state.exploring ? void 0 : scopeIds(), reducedMotion: state.reduce }) : null;
  if (journey?.length > 1 && plan?.route && resolve(journey[0]) === state.previousFocus && resolve(journey.at(-1)) === focus) {
    const ids = journey.map(resolve);
    const routeEdges2 = [];
    for (let i = 1; i < ids.length; i++) {
      const route2 = findEngineeringRoute(state.graph, { from: ids[i - 1], to: ids[i], scopeIds: scopeIds(), maxHops: 1 });
      if (!route2.found) throw Error("Saved journey no longer resolves within the presentation boundary");
      routeEdges2.push(...route2.relationships);
    }
    plan.route = { found: true, elements: ids.map(element), relationships: routeEdges2 };
    const stage = plan.stages.find((s) => s.kind === "gv-journey");
    if (stage) {
      stage.route = routeEdges2;
      stage.semanticIds = ids;
    }
  }
  const disconnected = plan?.mode === "cross-kind" && plan.route?.found === false;
  if (disconnected && !state.exploring && !allowDisconnected) throw Error("No engineering route connects these viewpoints within the presentation system. Explore the model to open a disconnected viewpoint explicitly.");
  cancelAnimations();
  for (const p of $("stage").querySelectorAll(".narrative-outgoing")) p.remove();
  $("selection").hidden = true;
  state.transitioning = true;
  state.pendingDestination = { view, focus, journey };
  state.lastTransition = plan;
  let oldPanel;
  try {
    oldPanel = !$("narrative").hidden ? $("narrative").cloneNode(true) : null;
    if (oldPanel) {
      oldPanel.removeAttribute("id");
      oldPanel.classList.add("narrative-outgoing");
      oldPanel.setAttribute("aria-hidden", "true");
      $("stage").append(oldPanel);
    }
    const panels = panelGeometry(view), target = await prepareFrame(view, focus, panels), frames = [];
    if (revision !== state.revision) {
      oldPanel?.remove();
      return;
    }
    if (state.visualSnapshot && animate && !state.reduce) {
      frames.push(state.visualSnapshot);
      if (plan?.mode === "cross-kind" && !disconnected) {
        for (const step of plan.stages.slice(0, -1)) frames.push(await prepareFrame(gather(step.semanticIds), focus, panels));
      }
      frames.push(target);
    } else frames.push(target);
    if (revision !== state.revision) {
      oldPanel?.remove();
      return;
    }
    const result = await paintFrames(frames, { duration: frames.length > 2 ? 1700 : frames.length > 1 ? 780 : 0, caption: disconnected ? "No engineering route \xB7 explicit view jump" : "", outgoingPanel: oldPanel });
    if (result.cancelled || revision !== state.revision) return;
    state.view = view;
    state.focus = focus;
    state.previousFocus = focus;
    if (!state.exploring) status(`OpenSysML WASM \xB7 ${state.graph.elements.length} native elements \xB7 ${state.availableViews.length} views`);
    $("boundary").textContent = !scopeIds().includes(focus) ? "Outside presentation boundary \xB7 loaded model context" : state.project.manifest.publication.scope === "scoped" ? "Scoped publication \xB7 supplied model context only" : "Complete project \xB7 standalone exploration available";
  } finally {
    oldPanel?.remove();
    if (revision === state.revision) {
      state.transitioning = false;
      state.pendingDestination = null;
    }
  }
}
async function showScene(index, animate = true) {
  if (index < 0 || index >= state.scenes.length) return;
  const saved = { sceneIndex: state.sceneIndex, exploring: state.exploring, selected: state.selected };
  state.sceneIndex = index;
  state.exploring = false;
  state.selected = null;
  const s = scene();
  const focus = resolve(s.focus), view = state.views.get(s.view);
  let navigationRevision;
  try {
    if (!focus || !view) throw Error("Scene focus or native view is unavailable");
    const pending = transitionTo(view, focus, { animate, journey: s.journey, allowDisconnected: true });
    navigationRevision = state.revision;
    await pending;
  } catch (error) {
    if (navigationRevision !== void 0 && navigationRevision !== state.revision) return;
    Object.assign(state, saved);
    if (state.view) await frame(state.view);
    throw error;
  } finally {
    $("scenes").value = state.sceneIndex;
    $("previous").disabled = state.sceneIndex === 0;
    $("next").disabled = state.sceneIndex === state.scenes.length - 1;
    $("return").hidden = !state.exploring || !state.scenes.length;
    $("standalone").hidden = state.exploring;
  }
}
async function explore(id, kind) {
  if (!id || !element(id)) throw Error("Model target unavailable");
  const revision = ++state.revision, modelHash = state.modelHash;
  let view;
  if (kind) {
    const q = qname(id);
    if (!q) throw Error("Native view requires a qualified model identity");
    const raw = await state.engine.call("RenderView", { modelHash, view: `#${kind}:${q}`, includeSemanticIdentity: true });
    if (revision !== state.revision || modelHash !== state.modelHash) return;
    view = { ...requireNativeIdentity(adaptNativeView(raw, `#${kind}:${q}`)), capture: { definition: kind === "action" ? "ActionFlowView" : "InterconnectionView", root: q } };
    state.extraViews ??= /* @__PURE__ */ new Map();
    state.extraViews.set(view.id, view);
    state.graph = modelGraph(state.exported.elements, [...state.views.values(), state.coverage, ...state.extraViews.values()]);
  }
  if (revision !== state.revision) return;
  state.history.push({ view: state.view, focus: state.focus });
  state.exploring = true;
  $("return").hidden = !state.scenes.length;
  $("standalone").hidden = true;
  if (view) await transitionTo(view, id);
  else {
    const context = engineeringContext(state.graph, { focus: id, depth: 1, budget: 14 });
    await transitionTo(graphView(state.graph, context), id);
    status(`Focused General View \xB7 ${context.elements.length} elements \xB7 ${context.omissions.length} context boundaries (details available)`);
  }
}
function select(id, node) {
  clearTrace();
  state.selected = id || null;
  for (const n of $("nodes").children) n.classList.toggle("selected", !!id && n.dataset.semanticId === id);
  const menu = $("selection");
  menu.replaceChildren(el("strong", node?.name || label(id)));
  menu.hidden = false;
  if (!id) {
    menu.append(el("p", "This native notation element or embedded port has no independent model-element identity in this projection."), button("Close", () => {
      menu.hidden = true;
    }));
    return;
  }
  const documentation = documentationFor(state.graph, id);
  if (documentation.text) menu.append(button("Read full statement", () => {
    $("information").classList.add("statement");
    $("information-title").textContent = "Full statement";
    $("information-text").textContent = (documentation.source?.qualifiedName || label(id)) + "\n\n" + documentation.text;
    $("information").showModal();
  }));
  menu.append(button("Focus", () => explore(id)), button(state.expanded.has(id) || !!node?.displayDetail ? "Collapse compartment" : "Show statement / compartment", async () => {
    if (state.expanded.has(id) || !!node?.displayDetail) {
      state.expanded.delete(id);
      state.collapsed.add(id);
    } else {
      state.collapsed.delete(id);
      state.expanded.add(id);
    }
    await frame(state.view);
    select(id, node);
  }));
  const e = element(id);
  if (["PartUsage", "PartDefinition", "Package"].includes(e?.kind)) menu.append(button("Internal view", () => explore(id, "interconnection")));
  if (["ActionUsage", "ActionDefinition"].includes(e?.kind)) menu.append(button("Activity view", () => explore(id, "action")));
  const kinds = [...new Set(state.graph.relationships.filter((r) => r.source === id || r.target === id).map((r) => r.kind))].filter((k) => !["typing", "owner", "specialization"].includes(k));
  for (const kind of kinds) menu.append(button(`Follow ${kind} relationships`, async () => {
    state.exploring = true;
    $("return").hidden = !state.scenes.length;
    const context = engineeringContext(state.graph, { focus: id, relationshipKinds: [kind], depth: 1, budget: 14 });
    await transitionTo(graphView(state.graph, context), id);
  }));
  const typing = directTypingContext(state.graph, id);
  if (typing.elements.length > 1) menu.append(button("Show direct type context", async () => {
    state.exploring = true;
    $("return").hidden = !state.scenes.length;
    await transitionTo(graphView(state.graph, typing, "Explicit typing context"), id);
  }));
  menu.append(button("Close", () => {
    menu.hidden = true;
  }));
}
function clearTrace() {
  $("stage").classList.remove("tracing");
  for (const n of $("nodes").children) n.classList.remove("trace-endpoint");
  for (const e of $("connections").querySelectorAll("g[data-relationship]")) {
    e.classList.remove("traced");
    e.removeAttribute("aria-pressed");
  }
}
function traceEdge(edge, key) {
  clearTrace();
  $("stage").classList.add("tracing");
  for (const n of $("nodes").children) n.classList.toggle("trace-endpoint", [edge.sourceSemantic, edge.targetSemantic].includes(n.dataset.semanticId));
  for (const g of $("connections").querySelectorAll("g[data-relationship]")) {
    const match = g.dataset.relationship === String(edge.semanticId || edge.id) && g.dataset.source === (edge.sourceSemantic || "") && g.dataset.target === (edge.targetSemantic || "");
    g.classList.toggle("traced", match);
    g.setAttribute("aria-pressed", String(match));
  }
  const menu = $("selection");
  menu.replaceChildren(el("strong", edge.label || edge.kind), el("p", `${label(edge.sourceSemantic)} \u2192 ${label(edge.targetSemantic)}`));
  for (const id of [.../* @__PURE__ */ new Set([edge.sourceSemantic, edge.targetSemantic])].filter(Boolean)) menu.append(button("Focus " + label(id), () => explore(id)));
  menu.append(button("Close", () => {
    clearTrace();
    menu.hidden = true;
  }));
  menu.hidden = false;
}
function download(name, bytes, type) {
  const blob = new Blob([bytes], { type }), url = URL.createObjectURL(blob), a = el("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3e3);
}
function openEditor() {
  if (!state.project) return;
  $("scene-title").value = scene()?.title || "New scene";
  $("scene-prose").value = scene()?.markdown || "";
  $("panel-placement").value = scene()?.panel?.placement || "right";
  $("view-source").value = fileText(state.project, $("view-file").value);
  $("editor-error").textContent = "";
  $("editor").showModal();
}
async function capture() {
  if (!state.view) throw Error("Open a view before capturing a scene");
  let viewName = state.view.id;
  const project = structuredClone(state.project), number = state.scenes.length + 1;
  if (!state.views.has(viewName)) {
    if (!state.view.capture) throw Error("This focused graph cannot yet be captured faithfully as a native SysML view. Open a declared view, Internal view, or Activity view, then capture it.");
    const names = [state.view.capture.root];
    const name = "scene" + number;
    const packageName = "CanvasCaptured" + number;
    const filename = "captured-views.sysml";
    const declaration = captureViewSource({ packageName, name, qualifiedNames: names, definition: state.view.capture.definition });
    project.files[filename] = (project.files[filename] ? fileText(project, filename) + "\n" : "") + declaration;
    if (!project.manifest.viewSources.includes(filename)) project.manifest.viewSources.push(filename);
    viewName = packageName + "::" + name;
  }
  const s = { type: "scene", id: "captured-" + Date.now(), title: $("scene-title").value || "Captured view", view: viewName, focus: qname(state.focus), panel: { placement: $("panel-placement").value }, markdown: $("scene-prose").value };
  if (!s.focus) throw Error("Captured focus needs a native qualified identity");
  appendScene(project, s);
  await loadProject(project);
  await showScene(state.scenes.length - 1, false);
  $("editor").close();
  status("Scene captured. Export the project ZIP or Markdown to keep it.");
}
function bind() {
  $("previous").onclick = () => showScene(state.sceneIndex - 1).catch(report);
  $("next").onclick = () => showScene(state.sceneIndex + 1).catch(report);
  $("scenes").onchange = () => showScene(Number($("scenes").value)).catch(report);
  $("standalone").onclick = async () => {
    try {
      state.exploring = true;
      $("return").hidden = !state.scenes.length;
      $("standalone").hidden = true;
      await transitionTo(state.view, state.focus);
      status("Explore this native view \xB7 select an element for contextual actions");
    } catch (error) {
      report(error);
    }
  };
  $("return").onclick = () => showScene(state.sceneIndex).catch(report);
  $("fit").onclick = () => frame(state.view).catch(report);
  $("reduce").setAttribute("aria-pressed", state.reduce);
  $("reduce").onclick = () => {
    state.reduce = !state.reduce;
    $("reduce").setAttribute("aria-pressed", state.reduce);
    if (state.reduce) state.motion?.finish();
  };
  $("find-toggle").onclick = () => {
    $("find").hidden = !$("find").hidden;
    if (!$("find").hidden) $("search").focus();
  };
  $("search").oninput = () => {
    const q = $("search").value.trim().toLowerCase();
    $("search-results").replaceChildren();
    if (!q) return;
    const hits = state.graph.elements.filter((e) => e.qualifiedName && e.layer === "project" && e.native.declaredName && (e.name + " " + e.qualifiedName).toLowerCase().includes(q));
    for (const e of hits.slice(0, 30)) $("search-results").append(button(e.qualifiedName, async () => {
      $("find").hidden = true;
      await explore(e.id);
    }));
  };
  $("open-view").onclick = async () => {
    try {
      const revision = ++state.revision, modelHash = state.modelHash, name = $("views").value;
      let view = state.views.get(name);
      if (!view) {
        const raw = await state.engine.call("RenderView", { modelHash, view: name, includeSemanticIdentity: true });
        if (revision !== state.revision || modelHash !== state.modelHash) return;
        view = requireNativeIdentity(adaptNativeView(raw, name));
        if (!["requirement", "definition", "tree", "package", "interconnection", "action", "state"].includes(view.kind)) throw Error("This canvas does not yet render the native " + view.kind + " notation. The complete source remains included.");
        state.views.set(name, view);
        state.graph = modelGraph(state.exported.elements, [...state.views.values(), state.coverage, ...state.extraViews.values()]);
      }
      const target = view.nodes.find((n) => n.semanticId)?.semanticId;
      state.exploring = true;
      $("return").hidden = !state.scenes.length;
      $("find").hidden = true;
      await transitionTo(view, target);
    } catch (e) {
      report(e);
    }
  };
  $("context-details").onclick = () => {
    $("information").classList.remove("statement");
    $("information-title").textContent = "Context boundaries";
    const omissions = state.displayOmissions ?? state.displayed?.omissions ?? [];
    $("information-text").textContent = omissions.map((o) => `${["unavailable", "outside-scope", "metamodel-boundary"].includes(o.reason) ? "Unavailable / boundary" : "Hidden by view policy"}: ${o.reason} \xB7 ${label(o.target)} (${o.target})`).join("\n") + "\n\nCoverage: part composition, dependencies and direct types come from the native API. Other engineering links come from native requirement and declared views. Unprojected relationship kinds may be unavailable.";
    $("information").showModal();
  };
  $("edit").onclick = openEditor;
  $("view-file").onchange = () => {
    $("view-source").value = fileText(state.project, $("view-file").value);
  };
  $("save-scene").onclick = async () => {
    try {
      if (!scene()) throw Error("Capture a first scene before editing it");
      scene().title = $("scene-title").value;
      scene().markdown = $("scene-prose").value;
      scene().panel = { placement: $("panel-placement").value };
      state.project.files[state.project.manifest.story] = writeStory(state.project.manifest.title, state.scenes);
      updateLists();
      $("editor").close();
      await showScene(state.sceneIndex, false);
    } catch (e) {
      report(e);
    }
  };
  $("capture-scene").onclick = () => capture().catch(report);
  $("apply-views").onclick = async () => {
    try {
      const project = structuredClone(state.project);
      project.files[$("view-file").value] = $("view-source").value;
      await loadProject(project);
      $("editor").close();
    } catch (e) {
      report(e);
    }
  };
  $("import-project").onclick = () => {
    $("project-file").click();
  };
  $("project-file").onchange = async () => {
    try {
      const file = $("project-file").files[0];
      if (file) await loadProject(unpackProject(new Uint8Array(await file.arrayBuffer())));
    } catch (e) {
      report(e);
    } finally {
      $("project-file").value = "";
    }
  };
  $("import-markdown").onclick = () => {
    $("markdown-file").click();
  };
  $("markdown-file").onchange = async () => {
    try {
      const file = $("markdown-file").files[0];
      if (file) {
        const project = structuredClone(state.project);
        project.files[project.manifest.story] = await file.text();
        await loadProject(project);
      }
    } catch (e) {
      report(e);
    } finally {
      $("markdown-file").value = "";
    }
  };
  $("export-project").onclick = () => {
    try {
      download("syspresent-project.zip", packProject(state.project), "application/zip");
      $("project-menu").open = false;
    } catch (e) {
      report(e);
    }
  };
  $("export-markdown").onclick = () => {
    download("story.md", fileText(state.project, state.project.manifest.story), "text/markdown");
    $("project-menu").open = false;
  };
  $("load-example").onclick = () => exampleProject().then(loadProject).catch(report);
  $("about").onclick = () => {
    $("information").classList.remove("statement");
    $("information-title").textContent = "Engine and project details";
    $("information-text").textContent = JSON.stringify({ engine: state.provenance, project: state.project.manifest, modelHash: state.modelHash, graph: { elements: state.graph.elements.length, relationships: state.graph.relationships.length }, view: state.view.id, lastTransition: state.lastTransition, notice: state.exported.notice }, null, 2);
    $("information").showModal();
  };
  $("stage").onclick = (e) => {
    if (e.target === $("stage") || e.target === $("nodes") || e.target === $("connections")) {
      clearTrace();
      $("selection").hidden = true;
    }
  };
  let resize;
  new ResizeObserver(() => {
    clearTimeout(resize);
    resize = setTimeout(() => {
      if (state.transitioning && state.pendingDestination) {
        const pending = state.pendingDestination;
        transitionTo(pending.view, pending.focus, { journey: pending.journey, allowDisconnected: true }).catch(report);
      } else if (state.view) frame(state.view).catch(report);
    }, 100);
  }).observe($("stage"));
}
async function start() {
  bind();
  busy(true);
  state.layoutEngine = createLayoutEngine({ workerUrl: new URL("./layout/elk-worker.js?v=" + buildVersion, location.href).href });
  state.engine = createSemanticEngine({ assetBase: new URL("./engine/", location.href), assetVersion: buildVersion, workerURL: new URL("./engine/worker.js?v=" + buildVersion, location.href) });
  const [project, info] = await Promise.all([exampleProject(), state.engine.ready]);
  state.engineInfo = info;
  state.provenance = await fetch("./engine/provenance.json?v=" + buildVersion).then((r) => r.ok ? r.json() : info);
  await loadProject(project);
}
start().catch(report);
//# sourceMappingURL=app.js.map
